package eu.neoteric.wizura

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
