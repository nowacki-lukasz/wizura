import 'package:flutter_test/flutter_test.dart';
import 'package:wizura/data/diving_spots.dart';
import 'package:wizura/models/hour_data.dart';
import 'package:wizura/models/spot_forecast.dart';
import 'package:wizura/models/vistula_state.dart';
import 'package:wizura/services/forecast_analyzer.dart';
import 'package:wizura/utils/angle_utils.dart';

void main() {
  const analyzer = ForecastAnalyzer();
  final now = DateTime(2026, 9, 5, 14, 30);
  final today = DateTime(2026, 9, 5);

  /// Buduje 3 dni historii + 6 dni prognozy z zadanym generatorem.
  SpotForecast buildForecast(HourData Function(DateTime t) gen) {
    final start = today.subtract(const Duration(days: 3));
    final hours = <HourData>[];
    for (var i = 0; i < 24 * 9; i++) {
      hours.add(gen(start.add(Duration(hours: i))));
    }
    return SpotForecast(spotId: 'orlowo', fetchedAt: now, hours: hours);
  }

  test('tworzy 20 bloków (5 dni × 4) i 5 dni', () {
    final f = buildForecast((t) => HourData(
          time: t,
          waveHeight: 0.2,
          windSpeed: 10,
          windDirection: 270,
        ));
    final a = analyzer.analyze(spotById('orlowo'), f, now: now);
    expect(a.blocks.length, 20);
    expect(a.days.length, 5);
    expect(a.blocks.first.start, today);
    expect(a.blocks.last.end, today.add(const Duration(days: 5)));
    expect(a.days.first.blocks.map((b) => b.hourLabel).toList(),
        ['00–06', '06–12', '12–18', '18–24']);
  });

  test('bieżący blok obejmuje "teraz"', () {
    final f = buildForecast((t) => HourData(time: t, waveHeight: 0.2));
    final a = analyzer.analyze(spotById('orlowo'), f, now: now);
    expect(a.current.start, DateTime(2026, 9, 5, 12));
    expect(a.current.contains(now), isTrue);
  });

  test('historia fali z 24 h i opad z 72 h są liczone z danych wstecz', () {
    final f = buildForecast((t) {
      // Sztorm wczoraj rano, deszcz przez ostatnie 3 dni po 1 mm/h.
      final stormy = t.isAfter(today.subtract(const Duration(hours: 20))) &&
          t.isBefore(today.subtract(const Duration(hours: 10)));
      return HourData(
        time: t,
        waveHeight: stormy ? 1.4 : 0.2,
        precipitation: t.isBefore(today) ? 1.0 : 0.0,
        windSpeed: 5,
        windDirection: 270,
      );
    });
    final a = analyzer.analyze(spotById('orlowo'), f, now: now);
    final first = a.blocks.first; // 00–06 dziś
    expect(first.conditions.maxWaveHeight24h, closeTo(1.4, 1e-9));
    expect(first.conditions.precipitation72h, closeTo(72, 1e-9));
    expect(first.estimate.factors.firstWhere((x) => x.key == 'history').multiplier,
        0.65);

    // Jutro rano sztorm jest już poza oknem 24 h.
    final tomorrowMorning = a.blocks[5]; // dzień 1, 06–12
    expect(tomorrowMorning.conditions.maxWaveHeight24h, closeTo(0.2, 1e-9));
  });

  test('średnia kołowa kierunku wiatru wokół północy', () {
    final f = buildForecast((t) => HourData(
          time: t,
          windSpeed: 10,
          windDirection: t.hour.isEven ? 350 : 10,
        ));
    final a = analyzer.analyze(spotById('orlowo'), f, now: now);
    expect(a.current.conditions.windDirection!, closeTo(0, 1e-6));
  });

  test('stan Wisły trafia do warunków każdego bloku', () {
    final f = buildForecast((t) => HourData(time: t, waveHeight: 0.2)).copyWith(
      vistula: VistulaState(
        stationName: 'Tczew',
        fetchedAt: now,
        waterLevelCm: 500,
        warningLevelCm: 700,
      ),
    );
    final a = analyzer.analyze(spotById('gorki-zachodnie'), f, now: now);
    expect(a.blocks.every((b) => b.conditions.vistulaLevelCm == 500), isTrue);
    expect(
      a.blocks.first.estimate.factors.firstWhere((x) => x.key == 'vistula').multiplier,
      lessThan(1.0),
    );
  });

  test('rekomendacja: brzeg bezpieczny przy małej fali', () {
    final f = buildForecast((t) => HourData(
          time: t,
          waveHeight: 0.2,
          windSpeed: 8,
          windDirection: 270,
          seaSurfaceTemperature: 12,
        ));
    final a = analyzer.analyze(spotById('orlowo'), f, now: now);
    expect(a.todayRecommendation.entryAssessment, contains('bezpieczne'));
    expect(a.todayRecommendation.summary, contains('Warto jechać'));
  });

  test('rekomendacja: łódź ryzykowna przy dużej fali, Franken ostrzega o trimix', () {
    final f = buildForecast((t) => HourData(
          time: t,
          waveHeight: 1.6,
          windSpeed: 45,
          windDirection: 20,
        ));
    final a = analyzer.analyze(spotById('franken'), f, now: now);
    expect(a.todayRecommendation.entryAssessment, contains('ryzykowne'));
    expect(a.todayRecommendation.warnings.any((w) => w.contains('trimix')), isTrue);
  });

  test('brak danych w bloku nie wywala analizy', () {
    final f = SpotForecast(
      spotId: 'orlowo',
      fetchedAt: now,
      hours: [HourData(time: today.add(const Duration(hours: 3)), waveHeight: 0.2)],
    );
    final a = analyzer.analyze(spotById('orlowo'), f, now: now);
    expect(a.blocks.length, 20);
    expect(a.blocks[1].estimate.meters, 5.5);
    expect(a.recommendations.length, 5);
  });

  group('AngleUtils', () {
    test('difference', () {
      expect(AngleUtils.difference(10, 350), 20);
      expect(AngleUtils.difference(90, 270), 180);
      expect(AngleUtils.difference(225, 45), 180);
      expect(AngleUtils.difference(0, 0), 0);
    });

    test('compassName', () {
      expect(AngleUtils.compassName(0), 'N');
      expect(AngleUtils.compassName(90), 'E');
      expect(AngleUtils.compassName(225), 'SW');
      expect(AngleUtils.compassName(359), 'N');
    });
  });
}
