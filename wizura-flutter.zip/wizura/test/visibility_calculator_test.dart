import 'package:flutter_test/flutter_test.dart';
import 'package:wizura/data/diving_spots.dart';
import 'package:wizura/models/diving_spot.dart';
import 'package:wizura/models/time_block.dart';
import 'package:wizura/models/visibility_estimate.dart';
import 'package:wizura/services/visibility_calculator.dart';

void main() {
  const calc = VisibilityCalculator();
  final orlowo = spotById('orlowo'); // brzeg 90° (E), płytki
  final franken = spotById('franken'); // otwarte morze, głęboki
  final gorki = spotById('gorki-zachodnie'); // ujście Wisły, brzeg 0° (N)
  final winter = DateTime(2026, 2, 10, 12);
  final summer = DateTime(2026, 8, 10, 12);

  double factor(VisibilityEstimate e, String key) =>
      e.factors.firstWhere((f) => f.key == key).multiplier;

  group('VisibilityCalculator – warunki bazowe', () {
    test('flauta, wiatr od lądu, zimna woda daje bazę +10% (6.1 m)', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(
          windSpeed: 10,
          windGusts: 12,
          windDirection: 270, // W – od lądu dla brzegu E
          waveHeight: 0.1,
          wavePeriod: 3,
          waveDirection: 270,
          seaSurfaceTemperature: 8,
          precipitation72h: 0,
          maxWaveHeight24h: 0.2,
        ),
        time: winter,
      );
      expect(factor(e, 'wind'), closeTo(1.10, 1e-9));
      expect(factor(e, 'wave'), 1.0);
      expect(factor(e, 'history'), 1.0);
      expect(e.meters, closeTo(6.1, 1e-9)); // 5.5 * 1.1 = 6.05 -> 6.1
      expect(e.category, ConditionCategory.good);
    });

    test('brak jakichkolwiek danych zwraca bazę 5.5 m bez wyjątku', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(),
        time: winter,
      );
      expect(e.meters, 5.5);
      expect(e.factors.every((f) => f.multiplier == 1.0), isTrue);
    });
  });

  group('Wiatr vs brzeg', () {
    test('onshore słaby (<=10 km/h) redukuje o 25%', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(windSpeed: 8, windDirection: 90, waveHeight: 0.1),
        time: winter,
      );
      expect(factor(e, 'wind'), closeTo(0.75, 1e-9));
    });

    test('onshore silny (>=40 km/h) redukuje o 60%', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(windSpeed: 45, windDirection: 100, waveHeight: 0.1),
        time: winter,
      );
      expect(factor(e, 'wind'), closeTo(0.40, 1e-9));
    });

    test('onshore 25 km/h daje redukcję pośrednią (42.5%)', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(windSpeed: 25, windDirection: 90, waveHeight: 0.1),
        time: winter,
      );
      expect(factor(e, 'wind'), closeTo(0.575, 1e-9));
    });

    test('granica 45° traktowana jako cross-shore, nie onshore', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(windSpeed: 10, windDirection: 135, waveHeight: 0.1),
        time: winter,
      );
      expect(factor(e, 'wind'), 1.0);
    });

    test('offshore (>135°) daje +10%', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(windSpeed: 30, windDirection: 250, waveHeight: 0.1),
        time: winter,
      );
      expect(factor(e, 'wind'), closeTo(1.10, 1e-9));
    });

    test('porywy podnoszą efektywną prędkość wiatru', () {
      const c = BlockConditions(windSpeed: 20, windGusts: 40);
      expect(c.effectiveWindSpeed, closeTo(26, 1e-9));
    });

    test('otwarte morze ignoruje kąt brzegu', () {
      final e = calc.estimate(
        spot: franken,
        c: const BlockConditions(windSpeed: 20, windDirection: 90, waveHeight: 0.1),
        time: winter,
      );
      expect(factor(e, 'wind'), 1.0);
    });
  });

  group('Wysokość fali', () {
    for (final (hs, expected) in [
      (0.1, 1.0),
      (0.29, 1.0),
      (0.3, 0.75),
      (0.79, 0.75),
      (0.8, 0.45),
      (1.5, 0.45),
      (1.51, 0.2),
      (2.5, 0.2),
    ]) {
      test('Hs=$hs -> mnożnik $expected', () {
        final e = calc.estimate(
          spot: orlowo,
          c: BlockConditions(waveHeight: hs),
          time: winter,
        );
        expect(factor(e, 'wave'), expected);
      });
    }

    test('brak fali z modelu -> estymacja z wiatru i notatka', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(windSpeed: 40, windDirection: 270),
        time: winter,
      );
      // 40 km/h = 11.1 m/s -> 0.0075 * 123 = ~0.93 m -> mnożnik 0.45
      expect(factor(e, 'wave'), 0.45);
      expect(e.notes, isNotEmpty);
    });
  });

  group('Historia falowania', () {
    test('max fala >1.0 m w 24 h daje 0.65', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(waveHeight: 0.1, maxWaveHeight24h: 1.2),
        time: winter,
      );
      expect(factor(e, 'history'), 0.65);
    });

    test('dokładnie 1.0 m nie uruchamia kary', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(waveHeight: 0.1, maxWaveHeight24h: 1.0),
        time: winter,
      );
      expect(factor(e, 'history'), 1.0);
    });
  });

  group('Charakter fali', () {
    test('krótka fala wiatrowa na płyciźnie -> 0.85', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(waveHeight: 0.5, wavePeriod: 3.0, waveDirection: 270),
        time: winter,
      );
      expect(factor(e, 'waveType'), closeTo(0.85, 1e-9));
    });

    test('fala prosto w brzeg (>=0.5 m) -> dodatkowe 0.85', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(waveHeight: 0.6, wavePeriod: 5.0, waveDirection: 90),
        time: winter,
      );
      expect(factor(e, 'waveType'), closeTo(0.85, 1e-9));
    });

    test('oba efekty łączą się multiplikatywnie', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(waveHeight: 0.6, wavePeriod: 3.0, waveDirection: 90),
        time: winter,
      );
      expect(factor(e, 'waveType'), closeTo(0.7225, 1e-9));
    });

    test('fala < 0.3 m nie ma charakteru', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(waveHeight: 0.2, wavePeriod: 2.0, waveDirection: 90),
        time: winter,
      );
      expect(factor(e, 'waveType'), 1.0);
    });
  });

  group('Opady i Wisła', () {
    test('ulewy >30 mm -> 0.7', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(precipitation72h: 42),
        time: winter,
      );
      expect(factor(e, 'rain'), 0.7);
    });

    test('wysoki przepływ Wisły uderza w Górki (pełna kara 0.5)', () {
      final e = calc.estimate(
        spot: gorki,
        c: const BlockConditions(vistulaFlowM3s: 2000),
        time: winter,
      );
      expect(factor(e, 'vistula'), closeTo(0.5, 1e-9));
    });

    test('ten sam przepływ w Orłowie to tylko część kary (wpływ 0.3)', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(vistulaFlowM3s: 2000),
        time: winter,
      );
      // 1 - 0.3 * (1 - 0.5) = 0.85
      expect(factor(e, 'vistula'), closeTo(0.85, 1e-9));
    });

    test('stan wody względem ostrzegawczego, gdy brak przepływu', () {
      final e = calc.estimate(
        spot: gorki,
        c: const BlockConditions(vistulaLevelCm: 400, vistulaWarningLevelCm: 700),
        time: winter,
      );
      // 400/700 = 0.57 -> podwyższony -> 0.75
      expect(factor(e, 'vistula'), closeTo(0.75, 1e-9));
    });

    test('Wisła w normie -> 1.0', () {
      final e = calc.estimate(
        spot: gorki,
        c: const BlockConditions(vistulaLevelCm: 217, vistulaWarningLevelCm: 700),
        time: winter,
      );
      expect(factor(e, 'vistula'), 1.0);
    });
  });

  group('Temperatura wody', () {
    test('latem >=20 °C -> zakwit 0.7', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(seaSurfaceTemperature: 21),
        time: summer,
      );
      expect(factor(e, 'temp'), 0.7);
    });

    test('zimą ciepła woda nie jest karana', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(seaSurfaceTemperature: 21),
        time: winter,
      );
      expect(factor(e, 'temp'), 1.0);
    });

    test('głęboki wrak nie dostaje kary za zakwit', () {
      final e = calc.estimate(
        spot: franken,
        c: const BlockConditions(seaSurfaceTemperature: 21),
        time: summer,
      );
      expect(factor(e, 'temp'), 1.0);
    });

    test('upwelling: spadek >=3 °C przy wietrze od lądu -> 1.15', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(
          seaSurfaceTemperature: 14,
          seaSurfaceTemperature48hAgo: 19,
          windDirection: 270,
          windSpeed: 20,
        ),
        time: summer,
      );
      expect(factor(e, 'temp'), closeTo(1.15, 1e-9));
    });
  });

  group('Głębokość, obcięcie i zaokrąglenie', () {
    test('Franken dostaje bonus 1.3', () {
      final e = calc.estimate(spot: franken, c: const BlockConditions(), time: winter);
      expect(factor(e, 'depth'), closeTo(1.3, 1e-9));
      expect(e.meters, closeTo(7.2, 1e-9)); // 5.5 * 1.3 = 7.15 -> 7.2
    });

    test('wynik nigdy nie przekracza 8.0 m', () {
      final e = calc.estimate(
        spot: franken,
        c: const BlockConditions(
          windSpeed: 5,
          windDirection: 270,
          waveHeight: 0.1,
          seaSurfaceTemperature: 6,
          seaSurfaceTemperature48hAgo: 12,
        ),
        time: winter,
      );
      expect(e.meters, lessThanOrEqualTo(8.0));
    });

    test('sztorm onshore po sztormie daje minimum 0.5 m', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(
          windSpeed: 60,
          windGusts: 90,
          windDirection: 90,
          waveHeight: 2.2,
          wavePeriod: 3.5,
          waveDirection: 90,
          maxWaveHeight24h: 2.5,
          precipitation72h: 40,
          seaSurfaceTemperature: 21,
        ),
        time: summer,
      );
      expect(e.meters, 0.5);
      expect(e.rawMeters, lessThan(0.5));
      expect(e.category, ConditionCategory.poor);
    });

    test('zaokrąglenie do jednego miejsca po przecinku', () {
      final e = calc.estimate(
        spot: orlowo,
        c: const BlockConditions(waveHeight: 0.5), // 5.5 * 0.75 = 4.125
        time: winter,
      );
      expect(e.meters, closeTo(4.1, 1e-9));
    });
  });

  group('Kategorie warunków', () {
    test('progi 2.0 i 4.0', () {
      expect(ConditionCategory.fromVisibility(4.1), ConditionCategory.good);
      expect(ConditionCategory.fromVisibility(4.0), ConditionCategory.medium);
      expect(ConditionCategory.fromVisibility(2.0), ConditionCategory.medium);
      expect(ConditionCategory.fromVisibility(1.9), ConditionCategory.poor);
    });
  });

  group('Baza spotów', () {
    test('jest dokładnie 10 spotów z unikalnymi id', () {
      expect(divingSpots.length, 10);
      expect(divingSpots.map((s) => s.id).toSet().length, 10);
    });

    test('Franken jest otwartym morzem i głębokim wrakiem', () {
      expect(franken.isOpenWater, isTrue);
      expect(franken.isDeep, isTrue);
      expect(franken.entryType, EntryType.boat);
    });
  });
}
