import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:wizura/models/spot_forecast.dart';
import 'package:wizura/services/imgw_service.dart';
import 'package:wizura/services/open_meteo_service.dart';

const marineJson = '''
{
  "latitude": 54.6, "longitude": 18.8, "timezone": "Europe/Warsaw",
  "hourly_units": {"time": "iso8601", "wave_height": "m"},
  "hourly": {
    "time": ["2026-09-05T00:00", "2026-09-05T01:00", "2026-09-05T02:00"],
    "wave_height": [0.4, 0.5, null],
    "wave_direction": [90, 95, 100],
    "wave_period": [3.2, 3.4, 3.6],
    "wind_wave_height": [0.3, 0.4, 0.4],
    "wind_wave_period": [3.0, 3.1, 3.2],
    "swell_wave_height": [0.1, 0.1, 0.1],
    "sea_surface_temperature": [17.2, 17.1, 17.0]
  }
}
''';

const weatherJson = '''
{
  "latitude": 54.6, "longitude": 18.8, "timezone": "Europe/Warsaw",
  "hourly": {
    "time": ["2026-09-05T01:00", "2026-09-05T02:00", "2026-09-05T03:00"],
    "wind_speed_10m": [12.5, 14.0, 15.5],
    "wind_direction_10m": [80, 85, 90],
    "wind_gusts_10m": [20.0, 22.0, 25.0],
    "precipitation": [0.0, 0.3, 1.2]
  }
}
''';

void main() {
  group('OpenMeteoService', () {
    test('parsuje Marine z nullami', () {
      final hours = OpenMeteoService.parseMarine(
          json.decode(marineJson) as Map<String, dynamic>);
      expect(hours.length, 3);
      expect(hours[0].waveHeight, 0.4);
      expect(hours[2].waveHeight, isNull);
      expect(hours[0].seaSurfaceTemperature, 17.2);
      expect(hours[0].time, DateTime(2026, 9, 5, 0));
    });

    test('scala Marine i Weather po czasie (unia godzin)', () {
      final m = OpenMeteoService.parseMarine(
          json.decode(marineJson) as Map<String, dynamic>);
      final w = OpenMeteoService.parseWeather(
          json.decode(weatherJson) as Map<String, dynamic>);
      final merged = OpenMeteoService.mergeHours(m, w);
      expect(merged.length, 4); // 00,01,02 ∪ 01,02,03
      final h1 = merged.firstWhere((h) => h.time.hour == 1);
      expect(h1.waveHeight, 0.5);
      expect(h1.windSpeed, 12.5);
      expect(h1.windGusts, 20.0);
      final h3 = merged.firstWhere((h) => h.time.hour == 3);
      expect(h3.waveHeight, isNull);
      expect(h3.precipitation, 1.2);
    });

    test('fetchHours używa obu endpointów i zwraca posortowane godziny', () async {
      final client = MockClient((request) async {
        if (request.url.host == OpenMeteoService.marineHost) {
          expect(request.url.queryParameters['hourly'], contains('sea_surface_temperature'));
          expect(request.url.queryParameters['timezone'], 'Europe/Warsaw');
          return http.Response(marineJson, 200);
        }
        expect(request.url.queryParameters['hourly'], contains('wind_gusts_10m'));
        return http.Response(weatherJson, 200);
      });
      final service = OpenMeteoService(client: client);
      final hours = await service.fetchHours(54.6, 18.8);
      expect(hours.length, 4);
      for (var i = 1; i < hours.length; i++) {
        expect(hours[i].time.isAfter(hours[i - 1].time), isTrue);
      }
    });

    test('błąd HTTP rzuca OpenMeteoException', () async {
      final client = MockClient((_) async => http.Response('nope', 500));
      final service = OpenMeteoService(client: client);
      expect(() => service.fetchHours(54.6, 18.8), throwsA(isA<OpenMeteoException>()));
    });

    test('błąd logiczny API rzuca OpenMeteoException', () async {
      final client = MockClient((_) async =>
          http.Response('{"error":true,"reason":"Invalid parameter"}', 200));
      final service = OpenMeteoService(client: client);
      expect(() => service.fetchHours(54.6, 18.8), throwsA(isA<OpenMeteoException>()));
    });
  });

  group('ImgwService', () {
    test('parsuje stację Tczew', () {
      final state = ImgwService.parseStation({
        'id_stacji': '154180150',
        'stacja': 'Tczew',
        'rzeka': 'Wisła',
        'stan_wody': '217',
        'stan_wody_data_pomiaru': '2026-09-05 01:20:00',
        'stan_ostrzegawczy': '700',
        'stan_alarmowy': '820',
        'przeplyw': null,
      });
      expect(state, isNotNull);
      expect(state!.waterLevelCm, 217);
      expect(state.flowM3s, isNull);
      expect(state.warningLevelCm, 700);
      expect(state.measuredAt, DateTime(2026, 9, 5, 1, 20));
    });

    test('fetchVistula: pełna lista jako fallback', () async {
      var calls = 0;
      final client = MockClient((request) async {
        calls++;
        if (request.url.path.contains('/id/')) {
          return http.Response('Not found', 404);
        }
        return http.Response(
          json.encode([
            {'id_stacji': '1', 'stacja': 'Inna', 'stan_wody': '100'},
            {'id_stacji': '154180150', 'stacja': 'Tczew', 'stan_wody': '300', 'przeplyw': '1200'},
          ]),
          200,
        );
      });
      final service = ImgwService(client: client);
      final v = await service.fetchVistula();
      expect(calls, 2);
      expect(v!.waterLevelCm, 300);
      expect(v.flowM3s, 1200);
    });

    test('fetchVistula: awaria API zwraca null zamiast wyjątku', () async {
      final client = MockClient((_) async => throw Exception('offline'));
      final service = ImgwService(client: client);
      expect(await service.fetchVistula(), isNull);
    });
  });

  group('Serializacja cache', () {
    test('SpotForecast round-trip przez JSON', () {
      final m = OpenMeteoService.parseMarine(
          json.decode(marineJson) as Map<String, dynamic>);
      final w = OpenMeteoService.parseWeather(
          json.decode(weatherJson) as Map<String, dynamic>);
      final forecast = SpotForecast(
        spotId: 'bryza',
        fetchedAt: DateTime(2026, 9, 5, 14),
        hours: OpenMeteoService.mergeHours(m, w),
        vistula: ImgwService.parseStation({'stacja': 'Tczew', 'stan_wody': '217'}),
      );
      final restored =
          SpotForecast.fromJson(json.decode(json.encode(forecast.toJson())) as Map<String, dynamic>);
      expect(restored.spotId, 'bryza');
      expect(restored.hours.length, forecast.hours.length);
      expect(restored.hours[1].waveHeight, 0.5);
      expect(restored.hours[1].windSpeed, 12.5);
      expect(restored.vistula!.waterLevelCm, 217);
    });
  });
}
