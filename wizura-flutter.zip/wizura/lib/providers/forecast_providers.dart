import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/diving_spots.dart';
import '../models/diving_spot.dart';
import '../models/spot_analysis.dart';
import '../models/spot_forecast.dart';
import '../services/forecast_analyzer.dart';
import '../services/forecast_cache_service.dart';
import '../services/forecast_repository.dart';
import '../services/imgw_service.dart';
import '../services/open_meteo_service.dart';

/// Lista spotów (statyczna).
final spotsProvider = Provider<List<DivingSpot>>((ref) => divingSpots);

final forecastRepositoryProvider = Provider<ForecastRepository>((ref) {
  final openMeteo = OpenMeteoService();
  final imgw = ImgwService();
  ref.onDispose(() {
    openMeteo.dispose();
    imgw.dispose();
  });
  return ForecastRepository(
    openMeteo: openMeteo,
    imgw: imgw,
    cache: ForecastCacheService(),
  );
});

final forecastAnalyzerProvider =
    Provider<ForecastAnalyzer>((ref) => const ForecastAnalyzer());

/// Stan prognoz dla wszystkich spotów.
class ForecastState {
  const ForecastState({
    required this.forecasts,
    required this.updatedAt,
    required this.fromCache,
    this.offlineReason,
    this.partialErrors = const {},
  });

  final Map<String, SpotForecast> forecasts;

  /// Czas pobrania danych (z sieci lub zapisu cache).
  final DateTime updatedAt;

  /// `true`, gdy dane pochodzą z pamięci podręcznej, a nie z bieżącego pobrania.
  final bool fromCache;

  /// Powód pracy offline (komunikat błędu sieci), jeśli dotyczy.
  final String? offlineReason;

  /// Spoty, dla których ostatnie pobranie się nie udało.
  final Map<String, String> partialErrors;

  bool get isOffline => offlineReason != null;

  ForecastState copyWith({
    Map<String, SpotForecast>? forecasts,
    DateTime? updatedAt,
    bool? fromCache,
    String? offlineReason,
    bool clearOffline = false,
    Map<String, String>? partialErrors,
  }) =>
      ForecastState(
        forecasts: forecasts ?? this.forecasts,
        updatedAt: updatedAt ?? this.updatedAt,
        fromCache: fromCache ?? this.fromCache,
        offlineReason: clearOffline ? null : (offlineReason ?? this.offlineReason),
        partialErrors: partialErrors ?? this.partialErrors,
      );
}

/// Po tym czasie cache uznajemy za nieaktualny i próbujemy odświeżyć z sieci.
const Duration cacheFreshness = Duration(hours: 3);

class ForecastsNotifier extends AsyncNotifier<ForecastState> {
  @override
  Future<ForecastState> build() async {
    final repo = ref.read(forecastRepositoryProvider);
    final spots = ref.read(spotsProvider);
    final cached = await repo.loadCache();
    final now = DateTime.now();

    final cacheUsable = cached != null &&
        cached.forecasts.isNotEmpty &&
        _coversToday(cached, now);

    if (cacheUsable && now.difference(cached.savedAt) < cacheFreshness) {
      return ForecastState(
        forecasts: cached.forecasts,
        updatedAt: cached.savedAt,
        fromCache: true,
      );
    }

    try {
      final result = await repo.fetchAll(
        spots,
        fallback: cacheUsable ? cached.forecasts : null,
      );
      return ForecastState(
        forecasts: result.forecasts,
        updatedAt: result.fetchedAt,
        fromCache: false,
        partialErrors: result.errors,
      );
    } catch (e) {
      if (cacheUsable) {
        return ForecastState(
          forecasts: cached.forecasts,
          updatedAt: cached.savedAt,
          fromCache: true,
          offlineReason: _friendly(e),
        );
      }
      rethrow;
    }
  }

  /// Wymusza pobranie z sieci (pull-to-refresh). Przy błędzie zachowuje
  /// poprzednie dane i ustawia tryb offline.
  Future<void> refresh() async {
    final repo = ref.read(forecastRepositoryProvider);
    final spots = ref.read(spotsProvider);
    final previous = state.valueOrNull;

    state = const AsyncLoading<ForecastState>().copyWithPrevious(state);

    try {
      final result = await repo.fetchAll(spots, fallback: previous?.forecasts);
      state = AsyncData(ForecastState(
        forecasts: result.forecasts,
        updatedAt: result.fetchedAt,
        fromCache: false,
        partialErrors: result.errors,
      ));
    } catch (e, st) {
      if (previous != null) {
        state = AsyncData(previous.copyWith(
          fromCache: true,
          offlineReason: _friendly(e),
        ));
      } else {
        state = AsyncError(e, st);
      }
    }
  }

  static bool _coversToday(CachedForecasts cached, DateTime now) {
    final today = DateTime(now.year, now.month, now.day);
    final endOfToday = today.add(const Duration(days: 1));
    return cached.forecasts.values.every(
      (f) => f.hours.isNotEmpty && f.hours.last.time.isAfter(endOfToday),
    );
  }

  static String _friendly(Object e) {
    final s = e.toString();
    if (s.contains('SocketException') ||
        s.contains('Failed host lookup') ||
        s.contains('Connection') ||
        s.contains('TimeoutException')) {
      return 'Brak połączenia z internetem.';
    }
    return s.replaceFirst('OpenMeteoException: ', '');
  }
}

final forecastsProvider =
    AsyncNotifierProvider<ForecastsNotifier, ForecastState>(ForecastsNotifier.new);

/// Analiza (bloki, dni, rekomendacje) dla jednego spotu.
/// Zwraca `null`, gdy prognoza dla spotu nie jest jeszcze dostępna.
final spotAnalysisProvider = Provider.family<SpotAnalysis?, String>((ref, spotId) {
  final state = ref.watch(forecastsProvider).valueOrNull;
  final forecast = state?.forecasts[spotId];
  if (forecast == null) return null;
  final spot = ref.watch(spotsProvider).firstWhere((s) => s.id == spotId);
  final analyzer = ref.watch(forecastAnalyzerProvider);
  return analyzer.analyze(spot, forecast);
});

/// Analizy wszystkich spotów (w kolejności listy), z pominięciem brakujących.
final allAnalysesProvider = Provider<List<SpotAnalysis>>((ref) {
  final spots = ref.watch(spotsProvider);
  return [
    for (final s in spots)
      if (ref.watch(spotAnalysisProvider(s.id)) case final a?) a,
  ];
});

/// Sortowanie listy: domyślnie lub wg wizury malejąco.
enum SpotSort { defaultOrder, byVisibility }

final spotSortProvider = StateProvider<SpotSort>((ref) => SpotSort.defaultOrder);
