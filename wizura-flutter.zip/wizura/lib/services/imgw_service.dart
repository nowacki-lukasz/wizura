import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/vistula_state.dart';

/// Klient publicznego API hydrologicznego IMGW-PIB (bez klucza).
///
/// Zwraca stan wody i (jeśli dostępny) przepływ Wisły na stacji Tczew –
/// ostatniej stacji wodowskazowej przed ujściem do Zatoki Gdańskiej.
class ImgwService {
  ImgwService({http.Client? client, this.timeout = const Duration(seconds: 15)})
      : _client = client ?? http.Client();

  final http.Client _client;
  final Duration timeout;

  static const String host = 'danepubliczne.imgw.pl';
  static const String tczewStationId = '154180150';
  static const String tczewStationName = 'Tczew';

  Uri stationUri(String id) => Uri.https(host, '/api/data/hydro/id/$id');
  Uri allStationsUri() => Uri.https(host, '/api/data/hydro');

  /// Zwraca stan Wisły lub `null`, gdy API jest niedostępne – aplikacja
  /// działa wtedy bez tego czynnika.
  Future<VistulaState?> fetchVistula() async {
    try {
      final byId = await _get(stationUri(tczewStationId));
      final parsed = _parseAny(byId);
      if (parsed != null) return parsed;
    } catch (_) {
      // spróbujemy pełnej listy
    }
    try {
      final all = await _get(allStationsUri());
      return _parseAny(all, matchName: tczewStationName);
    } catch (_) {
      return null;
    }
  }

  Future<dynamic> _get(Uri uri) async {
    final response = await _client.get(uri, headers: {
      'Accept': 'application/json',
    }).timeout(timeout);
    if (response.statusCode != 200) {
      throw http.ClientException('HTTP ${response.statusCode}', uri);
    }
    return json.decode(utf8.decode(response.bodyBytes));
  }

  VistulaState? _parseAny(dynamic decoded, {String? matchName}) {
    if (decoded is Map<String, dynamic>) {
      return parseStation(decoded);
    }
    if (decoded is List) {
      for (final item in decoded) {
        if (item is! Map<String, dynamic>) continue;
        final id = item['id_stacji']?.toString();
        final name = item['stacja']?.toString();
        if (id == tczewStationId ||
            (matchName != null && name != null && name.toLowerCase() == matchName.toLowerCase())) {
          return parseStation(item);
        }
      }
    }
    return null;
  }

  /// Parsuje jeden obiekt stacji z API IMGW.
  static VistulaState? parseStation(Map<String, dynamic> json) {
    final name = json['stacja']?.toString() ?? tczewStationName;
    final level = _num(json['stan_wody']);
    final flow = _num(json['przeplyw']);
    if (level == null && flow == null) return null;
    return VistulaState(
      stationName: name,
      fetchedAt: DateTime.now(),
      waterLevelCm: level,
      flowM3s: flow,
      warningLevelCm: _num(json['stan_ostrzegawczy']),
      alarmLevelCm: _num(json['stan_alarmowy']),
      measuredAt: _date(json['stan_wody_data_pomiaru']) ?? _date(json['przeplyw_data']),
    );
  }

  static double? _num(dynamic v) {
    if (v == null) return null;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString().replaceAll(',', '.'));
  }

  static DateTime? _date(dynamic v) {
    if (v == null) return null;
    return DateTime.tryParse(v.toString().replaceFirst(' ', 'T'));
  }

  void dispose() => _client.close();
}
