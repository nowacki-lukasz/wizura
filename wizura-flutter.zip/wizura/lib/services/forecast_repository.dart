import '../models/diving_spot.dart';
import '../models/spot_forecast.dart';
import '../models/vistula_state.dart';
import 'forecast_cache_service.dart';
import 'imgw_service.dart';
import 'open_meteo_service.dart';

/// Wynik pobierania prognoz dla wszystkich spotów.
class FetchResult {
  const FetchResult({
    required this.forecasts,
    required this.fetchedAt,
    required this.errors,
  });

  final Map<String, SpotForecast> forecasts;
  final DateTime fetchedAt;

  /// Błędy per spot (spot id -> komunikat). Pusta mapa = wszystko OK.
  final Map<String, String> errors;

  bool get isComplete => errors.isEmpty;
}

/// Łączy API (Open-Meteo, IMGW) z lokalnym cache.
class ForecastRepository {
  ForecastRepository({
    required OpenMeteoService openMeteo,
    required ImgwService imgw,
    required ForecastCacheService cache,
  })  : _openMeteo = openMeteo,
        _imgw = imgw,
        _cache = cache;

  final OpenMeteoService _openMeteo;
  final ImgwService _imgw;
  final ForecastCacheService _cache;

  /// Maksymalna liczba równoległych zapytań do Open-Meteo.
  static const int _concurrency = 4;

  Future<CachedForecasts?> loadCache() => _cache.load();

  Future<void> clearCache() => _cache.clear();

  /// Pobiera prognozy dla listy spotów, dokleja stan Wisły i zapisuje cache.
  /// Spoty, których nie udało się pobrać, zachowują wartość z [fallback].
  Future<FetchResult> fetchAll(
    List<DivingSpot> spots, {
    Map<String, SpotForecast>? fallback,
  }) async {
    final now = DateTime.now();
    final vistulaFuture = _imgw.fetchVistula();

    final forecasts = <String, SpotForecast>{};
    final errors = <String, String>{};

    // Prosta pula: po _concurrency zapytań naraz, żeby nie zalać API.
    for (var i = 0; i < spots.length; i += _concurrency) {
      final batch = spots.skip(i).take(_concurrency).toList();
      final results = await Future.wait(batch.map((spot) async {
        try {
          final hours = await _openMeteo.fetchHours(spot.latitude, spot.longitude);
          if (hours.isEmpty) {
            throw OpenMeteoException('Pusta odpowiedź dla ${spot.name}');
          }
          return MapEntry(
            spot.id,
            SpotForecast(spotId: spot.id, fetchedAt: now, hours: hours),
          );
        } catch (e) {
          errors[spot.id] = e.toString();
          final old = fallback?[spot.id];
          return old == null ? null : MapEntry(spot.id, old);
        }
      }));
      for (final entry in results) {
        if (entry != null) forecasts[entry.key] = entry.value;
      }
    }

    VistulaState? vistula;
    try {
      vistula = await vistulaFuture;
    } catch (_) {
      vistula = null;
    }
    // Jeśli IMGW padło, zachowaj poprzedni odczyt (max 24 h).
    if (vistula == null && fallback != null) {
      final previous = fallback.values
          .map((f) => f.vistula)
          .whereType<VistulaState>()
          .toList();
      if (previous.isNotEmpty &&
          now.difference(previous.first.fetchedAt) < const Duration(hours: 24)) {
        vistula = previous.first;
      }
    }
    if (vistula != null) {
      for (final id in forecasts.keys.toList()) {
        forecasts[id] = forecasts[id]!.copyWith(vistula: vistula);
      }
    }

    if (forecasts.isEmpty) {
      throw OpenMeteoException(
          errors.values.isNotEmpty ? errors.values.first : 'Brak danych z API');
    }

    await _cache.save(forecasts, now);
    return FetchResult(forecasts: forecasts, fetchedAt: now, errors: errors);
  }
}
