import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/hour_data.dart';

/// Wyjątek rzucany przy problemach z API Open-Meteo.
class OpenMeteoException implements Exception {
  OpenMeteoException(this.message);
  final String message;

  @override
  String toString() => 'OpenMeteoException: $message';
}

/// Klient publicznego API Open-Meteo (bez klucza).
///
/// Marine:  wave_height, wave_direction, wave_period, wind_wave_height,
///          wind_wave_period, swell_wave_height, sea_surface_temperature
/// Weather: wind_speed_10m, wind_direction_10m, wind_gusts_10m, precipitation
class OpenMeteoService {
  OpenMeteoService({http.Client? client, this.timeout = const Duration(seconds: 20)})
      : _client = client ?? http.Client();

  final http.Client _client;
  final Duration timeout;

  static const String marineHost = 'marine-api.open-meteo.com';
  static const String weatherHost = 'api.open-meteo.com';
  static const String timezone = 'Europe/Warsaw';

  /// Dni historii potrzebne do liczenia opadów z 72 h i spadku SST z 48 h.
  static const int pastDays = 3;
  static const int forecastDays = 6; // dziś + 4 dni + zapas na strefę czasową

  Uri marineUri(double lat, double lon) => Uri.https(marineHost, '/v1/marine', {
        'latitude': lat.toString(),
        'longitude': lon.toString(),
        'hourly': 'wave_height,wave_direction,wave_period,wind_wave_height,'
            'wind_wave_period,swell_wave_height,sea_surface_temperature',
        'timezone': timezone,
        'past_days': pastDays.toString(),
        'forecast_days': forecastDays.toString(),
      });

  Uri weatherUri(double lat, double lon) => Uri.https(weatherHost, '/v1/forecast', {
        'latitude': lat.toString(),
        'longitude': lon.toString(),
        'hourly': 'wind_speed_10m,wind_direction_10m,wind_gusts_10m,precipitation',
        'timezone': timezone,
        'past_days': pastDays.toString(),
        'forecast_days': forecastDays.toString(),
      });

  /// Pobiera i scala dane Marine + Weather w listę godzin.
  Future<List<HourData>> fetchHours(double lat, double lon) async {
    final results = await Future.wait([
      _getJson(marineUri(lat, lon)),
      _getJson(weatherUri(lat, lon)),
    ]);
    return mergeHours(
      parseMarine(results[0]),
      parseWeather(results[1]),
    );
  }

  Future<Map<String, dynamic>> _getJson(Uri uri) async {
    final http.Response response;
    try {
      response = await _client.get(uri).timeout(timeout);
    } catch (e) {
      throw OpenMeteoException('Błąd połączenia z ${uri.host}: $e');
    }
    if (response.statusCode != 200) {
      throw OpenMeteoException(
          'HTTP ${response.statusCode} z ${uri.host}: ${_shorten(response.body)}');
    }
    final decoded = json.decode(response.body);
    if (decoded is! Map<String, dynamic>) {
      throw OpenMeteoException('Nieoczekiwany format odpowiedzi z ${uri.host}');
    }
    if (decoded['error'] == true) {
      throw OpenMeteoException(decoded['reason']?.toString() ?? 'Błąd API');
    }
    return decoded;
  }

  static String _shorten(String s) => s.length > 120 ? '${s.substring(0, 120)}…' : s;

  // ------------------------------------------------------------ parsowanie

  /// Parsuje odpowiedź Marine API do listy [HourData] (tylko pola morskie).
  static List<HourData> parseMarine(Map<String, dynamic> json) {
    final hourly = json['hourly'];
    if (hourly is! Map<String, dynamic>) {
      throw OpenMeteoException('Brak sekcji "hourly" w odpowiedzi Marine');
    }
    final times = _times(hourly);
    final wh = _series(hourly, 'wave_height', times.length);
    final wd = _series(hourly, 'wave_direction', times.length);
    final wp = _series(hourly, 'wave_period', times.length);
    final wwh = _series(hourly, 'wind_wave_height', times.length);
    final wwp = _series(hourly, 'wind_wave_period', times.length);
    final swh = _series(hourly, 'swell_wave_height', times.length);
    final sst = _series(hourly, 'sea_surface_temperature', times.length);

    return [
      for (var i = 0; i < times.length; i++)
        HourData(
          time: times[i],
          waveHeight: wh[i],
          waveDirection: wd[i],
          wavePeriod: wp[i],
          windWaveHeight: wwh[i],
          windWavePeriod: wwp[i],
          swellWaveHeight: swh[i],
          seaSurfaceTemperature: sst[i],
        ),
    ];
  }

  /// Parsuje odpowiedź Weather API do listy [HourData] (tylko pola pogodowe).
  static List<HourData> parseWeather(Map<String, dynamic> json) {
    final hourly = json['hourly'];
    if (hourly is! Map<String, dynamic>) {
      throw OpenMeteoException('Brak sekcji "hourly" w odpowiedzi Weather');
    }
    final times = _times(hourly);
    final ws = _series(hourly, 'wind_speed_10m', times.length);
    final wdir = _series(hourly, 'wind_direction_10m', times.length);
    final wg = _series(hourly, 'wind_gusts_10m', times.length);
    final pr = _series(hourly, 'precipitation', times.length);

    return [
      for (var i = 0; i < times.length; i++)
        HourData(
          time: times[i],
          windSpeed: ws[i],
          windDirection: wdir[i],
          windGusts: wg[i],
          precipitation: pr[i],
        ),
    ];
  }

  /// Scala dwie listy po znaczniku czasu; zwraca listę posortowaną rosnąco.
  static List<HourData> mergeHours(List<HourData> a, List<HourData> b) {
    final map = <DateTime, HourData>{};
    for (final h in a) {
      map[h.time] = h;
    }
    for (final h in b) {
      final existing = map[h.time];
      map[h.time] = existing == null ? h : existing.merge(h);
    }
    final list = map.values.toList()..sort((x, y) => x.time.compareTo(y.time));
    return list;
  }

  static List<DateTime> _times(Map<String, dynamic> hourly) {
    final raw = hourly['time'];
    if (raw is! List) throw OpenMeteoException('Brak osi czasu w odpowiedzi');
    // Open-Meteo zwraca czas lokalny (Europe/Warsaw) bez offsetu, np.
    // "2026-09-05T13:00" – DateTime.parse traktuje go jako czas lokalny urządzenia.
    return raw.map((t) => DateTime.parse(t as String)).toList();
  }

  static List<double?> _series(Map<String, dynamic> hourly, String key, int n) {
    final raw = hourly[key];
    if (raw is! List) return List<double?>.filled(n, null);
    return List<double?>.generate(
      n,
      (i) => i < raw.length && raw[i] != null ? (raw[i] as num).toDouble() : null,
    );
  }

  void dispose() => _client.close();
}
