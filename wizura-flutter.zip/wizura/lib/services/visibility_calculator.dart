import '../models/diving_spot.dart';
import '../models/time_block.dart';
import '../models/visibility_estimate.dart';
import '../utils/angle_utils.dart';

/// Lokalny algorytm estymacji widoczności podwodnej (wizury) w metrach.
///
/// Wynik = baza (5.5 m) × iloczyn mnożników czynników:
///  1. wiatr vs ekspozycja brzegu (onshore / cross / offshore),
///  2. wysokość fali znacznej Hs,
///  3. historia falowania (max Hs w poprzednich 24 h),
///  4. charakter fali (krótka fala wiatrowa vs martwa fala) i jej kierunek,
///  5. opady / spływ z lądu (72 h) oraz stan Wisły (IMGW),
///  6. temperatura wody (zakwit latem, upwelling),
///  7. głębokość spotu (wraki poniżej termokliny).
/// Wynik jest obcinany do zakresu 0.5–8.0 m i zaokrąglany do 0.1 m.
class VisibilityCalculator {
  const VisibilityCalculator();

  static const double baseVisibility = 5.5;
  static const double minVisibility = 0.5;
  static const double maxVisibility = 8.0;

  VisibilityEstimate estimate({
    required DivingSpot spot,
    required BlockConditions c,
    required DateTime time,
  }) {
    final factors = <VisibilityFactor>[];
    final notes = <String>[];

    // ---------------------------------------------------------------- fala
    // Jeżeli model morski nie zwrócił fali (punkt zbyt blisko brzegu),
    // szacujemy Hs z wiatru (prosta zależność fetch-limited dla Zatoki).
    double? waveHeight = c.waveHeight;
    if (waveHeight == null && c.effectiveWindSpeed != null) {
      waveHeight = estimateWaveFromWind(c.effectiveWindSpeed!);
      notes.add(
          'Brak danych o fali z modelu – wysokość fali oszacowano z wiatru.');
    }

    // ------------------------------------------------- 1. wiatr vs brzeg
    factors.add(_windFactor(spot, c));

    // ------------------------------------------------- 2. wysokość fali
    factors.add(_waveHeightFactor(waveHeight));

    // ------------------------------------------------- 3. historia fali
    factors.add(_waveHistoryFactor(c.maxWaveHeight24h));

    // ------------------------------------------------- 4. charakter fali
    factors.add(_waveCharacterFactor(spot, c, waveHeight));

    // ------------------------------------------------- 5. opady i Wisła
    factors.add(_rainFactor(c.precipitation72h));
    factors.add(_vistulaFactor(spot, c));

    // ------------------------------------------------- 6. temperatura wody
    factors.add(_temperatureFactor(spot, c, time));

    // ------------------------------------------------- 7. głębokość
    factors.add(_depthFactor(spot));

    var value = baseVisibility;
    for (final f in factors) {
      value *= f.multiplier;
    }

    final clamped = value.clamp(minVisibility, maxVisibility).toDouble();
    final rounded = (clamped * 10).round() / 10;

    return VisibilityEstimate(
      meters: rounded,
      rawMeters: value,
      factors: factors,
      notes: notes,
    );
  }

  /// Przybliżenie Hs [m] z prędkości wiatru [km/h] dla akwenu o ograniczonym
  /// rozbiegu (Zatoka Gdańska): Hs ≈ 0.0075 · U² (U w m/s).
  /// 20 km/h -> ~0.23 m, 30 km/h -> ~0.5 m, 40 km/h -> ~0.9 m, 50 km/h -> ~1.45 m.
  static double estimateWaveFromWind(double windKmh) {
    final ms = windKmh / 3.6;
    return (0.0075 * ms * ms).clamp(0.0, 3.0);
  }

  // ------------------------------------------------------------------ 1
  VisibilityFactor _windFactor(DivingSpot spot, BlockConditions c) {
    final speed = c.effectiveWindSpeed;
    final dir = c.windDirection;

    if (speed == null || dir == null) {
      return const VisibilityFactor(
        key: 'wind',
        label: 'Wiatr',
        multiplier: 1.0,
        note: 'Brak danych o wietrze.',
      );
    }

    if (spot.isOpenWater) {
      // Na otwartej wodzie nie ma "brzegu"; silny wiatr utrudnia jedynie
      // logistykę i lekko miesza warstwę powierzchniową.
      final m = speed > 35 ? 0.9 : 1.0;
      return VisibilityFactor(
        key: 'wind',
        label: 'Wiatr (otwarte morze)',
        multiplier: m,
        note: speed > 35
            ? 'Silny wiatr ${speed.round()} km/h – lekkie zmieszanie warstwy powierzchniowej.'
            : 'Wiatr ${speed.round()} km/h – bez wpływu na wizurę na głębokości.',
      );
    }

    final angleDiff = AngleUtils.difference(dir, spot.shoreFacingAngle);
    final dirName = AngleUtils.compassName(dir);

    if (angleDiff < 45) {
      // Onshore: redukcja 25% (wiatr <= 10 km/h) do 60% (>= 40 km/h).
      final t = ((speed - 10) / 30).clamp(0.0, 1.0);
      final reduction = 0.25 + 0.35 * t;
      return VisibilityFactor(
        key: 'wind',
        label: 'Wiatr od morza (onshore)',
        multiplier: 1 - reduction,
        note:
            'Wiatr $dirName ${speed.round()} km/h wieje prosto na brzeg – fala przybojowa podnosi osad.',
      );
    }

    if (angleDiff > 135) {
      return VisibilityFactor(
        key: 'wind',
        label: 'Wiatr od lądu (offshore)',
        multiplier: 1.10,
        note:
            'Wiatr $dirName ${speed.round()} km/h od lądu – gładka woda przy brzegu, brak zmętnienia.',
      );
    }

    // Cross-shore: łagodna redukcja rosnąca z siłą wiatru (0–15%).
    final t = ((speed - 15) / 30).clamp(0.0, 1.0);
    final reduction = 0.15 * t;
    return VisibilityFactor(
      key: 'wind',
      label: 'Wiatr wzdłuż brzegu',
      multiplier: 1 - reduction,
      note: reduction == 0
          ? 'Wiatr $dirName ${speed.round()} km/h wzdłuż brzegu – niewielki wpływ.'
          : 'Wiatr $dirName ${speed.round()} km/h wzdłuż brzegu – prąd wzdłużbrzegowy unosi drobny osad.',
    );
  }

  // ------------------------------------------------------------------ 2
  VisibilityFactor _waveHeightFactor(double? hs) {
    if (hs == null) {
      return const VisibilityFactor(
        key: 'wave',
        label: 'Wysokość fali',
        multiplier: 1.0,
        note: 'Brak danych o fali.',
      );
    }
    final double m;
    final String note;
    if (hs < 0.3) {
      m = 1.0;
      note = 'Flauta (Hs ${_m(hs)}) – woda spokojna.';
    } else if (hs < 0.8) {
      m = 0.75;
      note = 'Umiarkowana fala (Hs ${_m(hs)}) – lekkie zmętnienie przy dnie.';
    } else if (hs <= 1.5) {
      m = 0.45;
      note = 'Wysoka fala (Hs ${_m(hs)}) – wyraźne zmętnienie.';
    } else {
      m = 0.2;
      note = 'Sztorm (Hs ${_m(hs)}) – duże zmętnienie, zawiesina w całej toni.';
    }
    return VisibilityFactor(
      key: 'wave',
      label: 'Wysokość fali',
      multiplier: m,
      note: note,
    );
  }

  // ------------------------------------------------------------------ 3
  VisibilityFactor _waveHistoryFactor(double? max24h) {
    if (max24h == null) {
      return const VisibilityFactor(
        key: 'history',
        label: 'Historia falowania (24 h)',
        multiplier: 1.0,
        note: 'Brak danych historycznych.',
      );
    }
    if (max24h > 1.0) {
      return VisibilityFactor(
        key: 'history',
        label: 'Historia falowania (24 h)',
        multiplier: 0.65,
        note:
            'W ostatnich 24 h fala sięgała ${_m(max24h)} – dno wzburzone, osad jeszcze nie opadł.',
      );
    }
    return VisibilityFactor(
      key: 'history',
      label: 'Historia falowania (24 h)',
      multiplier: 1.0,
      note: 'W ostatnich 24 h fala nie przekroczyła 1,0 m (max ${_m(max24h)}).',
    );
  }

  // ------------------------------------------------------------------ 4
  VisibilityFactor _waveCharacterFactor(
      DivingSpot spot, BlockConditions c, double? hs) {
    if (hs == null || hs < 0.3 || spot.isOpenWater) {
      return const VisibilityFactor(
        key: 'waveType',
        label: 'Charakter fali',
        multiplier: 1.0,
        note: 'Fala zbyt mała lub otwarte morze – bez znaczenia.',
      );
    }

    var m = 1.0;
    final parts = <String>[];

    // Krótka, stroma fala wiatrowa (okres < 4 s) miesza osad na płyciźnie
    // dużo mocniej niż długa martwa fala o tej samej wysokości.
    final period = c.wavePeriod;
    if (period != null && spot.isShallow) {
      if (period < 4.0) {
        m *= 0.85;
        parts.add('krótka fala wiatrowa (${_s(period)}) na płyciźnie');
      } else if (period > 7.0 && (c.swellWaveHeight ?? 0) > (c.windWaveHeight ?? 0)) {
        m *= 1.05;
        parts.add('długa martwa fala (${_s(period)}) – mniej mieszania');
      }
    }

    // Fala idąca prosto na brzeg (niezależnie od aktualnego wiatru –
    // np. resztkowa fala po wczorajszym sztormie).
    final wdir = c.waveDirection;
    if (wdir != null && hs >= 0.5) {
      final diff = AngleUtils.difference(wdir, spot.shoreFacingAngle);
      if (diff < 45) {
        m *= 0.85;
        parts.add('fala z ${AngleUtils.compassName(wdir)} uderza prosto w brzeg');
      }
    }

    return VisibilityFactor(
      key: 'waveType',
      label: 'Charakter fali',
      multiplier: m,
      note: parts.isEmpty ? 'Fala bez dodatkowego wpływu.' : '${parts.join('; ')}.',
    );
  }

  // ------------------------------------------------------------------ 5a
  VisibilityFactor _rainFactor(double? rain72h) {
    if (rain72h == null) {
      return const VisibilityFactor(
        key: 'rain',
        label: 'Opady / spływ z lądu (72 h)',
        multiplier: 1.0,
        note: 'Brak danych o opadach.',
      );
    }
    final double m;
    final String note;
    if (rain72h > 30) {
      m = 0.7;
      note = 'Ulewy (${rain72h.round()} mm / 72 h) – silny spływ z lądu i kanałów burzowych.';
    } else if (rain72h > 15) {
      m = 0.85;
      note = 'Sporo deszczu (${rain72h.round()} mm / 72 h) – spływ z lądu mąci wodę przy brzegu.';
    } else if (rain72h > 5) {
      m = 0.95;
      note = 'Lekkie opady (${rain72h.round()} mm / 72 h) – nieznaczny wpływ.';
    } else {
      m = 1.0;
      note = 'Sucho (${rain72h.round()} mm / 72 h).';
    }
    return VisibilityFactor(
      key: 'rain',
      label: 'Opady / spływ z lądu (72 h)',
      multiplier: m,
      note: note,
    );
  }

  // ------------------------------------------------------------------ 5b
  VisibilityFactor _vistulaFactor(DivingSpot spot, BlockConditions c) {
    final level = c.vistulaLevelCm;
    final flow = c.vistulaFlowM3s;
    if (level == null && flow == null) {
      return const VisibilityFactor(
        key: 'vistula',
        label: 'Smuga Wisły (IMGW)',
        multiplier: 1.0,
        note: 'Brak danych IMGW o stanie Wisły.',
      );
    }

    // Poziom zmętnienia u ujścia: 0 = normalny, 1 = podwyższony, 2 = wysoki.
    final int severity;
    final String basis;
    if (flow != null) {
      severity = flow > 1600 ? 2 : (flow > 1000 ? 1 : 0);
      basis = 'przepływ ${flow.round()} m³/s w Tczewie';
    } else {
      final warn = c.vistulaWarningLevelCm ?? 700;
      final ratio = level! / warn;
      severity = ratio > 0.75 ? 2 : (ratio > 0.5 ? 1 : 0);
      basis = 'stan ${level.round()} cm w Tczewie';
    }

    if (severity == 0) {
      return VisibilityFactor(
        key: 'vistula',
        label: 'Smuga Wisły (IMGW)',
        multiplier: 1.0,
        note: 'Wisła w normie ($basis).',
      );
    }

    final fullPenalty = severity == 2 ? 0.5 : 0.75;
    final m = 1 - spot.vistulaInfluence * (1 - fullPenalty);
    return VisibilityFactor(
      key: 'vistula',
      label: 'Smuga Wisły (IMGW)',
      multiplier: m,
      note: severity == 2
          ? 'Wysoki stan Wisły ($basis) – smuga zawiesiny rozlewa się po Zatoce.'
          : 'Podwyższony stan Wisły ($basis) – zwiększona zawiesina w rejonie ujścia.',
    );
  }

  // ------------------------------------------------------------------ 6
  VisibilityFactor _temperatureFactor(
      DivingSpot spot, BlockConditions c, DateTime time) {
    final sst = c.seaSurfaceTemperature;
    if (sst == null) {
      return const VisibilityFactor(
        key: 'temp',
        label: 'Temperatura wody',
        multiplier: 1.0,
        note: 'Brak danych o temperaturze wody.',
      );
    }

    // Upwelling: wiatr od lądu wypycha ciepłą wodę powierzchniową, a z głębi
    // podchodzi zimna, czysta woda – wizura skokowo rośnie.
    final prev = c.seaSurfaceTemperature48hAgo;
    final dir = c.windDirection;
    final offshore = dir != null &&
        !spot.isOpenWater &&
        AngleUtils.difference(dir, spot.shoreFacingAngle) > 135;
    if (prev != null && prev - sst >= 3.0 && offshore) {
      return VisibilityFactor(
        key: 'temp',
        label: 'Upwelling',
        multiplier: 1.15,
        note:
            'Woda ochłodziła się o ${(prev - sst).toStringAsFixed(1)} °C przy wietrze od lądu – zimna, czysta woda z głębi.',
      );
    }

    final summer = time.month >= 6 && time.month <= 9;
    if (summer && !spot.isDeep) {
      if (sst >= 20) {
        return VisibilityFactor(
          key: 'temp',
          label: 'Zakwit (ciepła woda)',
          multiplier: 0.7,
          note: 'Woda ${_c(sst)} – wysokie ryzyko zakwitu sinic i glonów.',
        );
      }
      if (sst >= 18) {
        return VisibilityFactor(
          key: 'temp',
          label: 'Zakwit (ciepła woda)',
          multiplier: 0.8,
          note: 'Woda ${_c(sst)} – prawdopodobny zakwit, zielonkawa toń.',
        );
      }
      if (sst >= 16) {
        return VisibilityFactor(
          key: 'temp',
          label: 'Temperatura wody',
          multiplier: 0.9,
          note: 'Woda ${_c(sst)} – umiarkowana ilość planktonu.',
        );
      }
    }

    return VisibilityFactor(
      key: 'temp',
      label: 'Temperatura wody',
      multiplier: 1.0,
      note: 'Woda ${_c(sst)} – bez wpływu zakwitu.',
    );
  }

  // ------------------------------------------------------------------ 7
  VisibilityFactor _depthFactor(DivingSpot spot) {
    if (spot.isDeep) {
      return const VisibilityFactor(
        key: 'depth',
        label: 'Głęboki wrak (pod termokliną)',
        multiplier: 1.3,
        note: 'Poniżej termokliny osad z brzegu i plankton mają mniejszy wpływ.',
      );
    }
    return const VisibilityFactor(
      key: 'depth',
      label: 'Głębokość spotu',
      multiplier: 1.0,
      note: 'Płytki spot przybrzeżny – pełny wpływ fali i spływu.',
    );
  }

  static String _m(double v) => '${v.toStringAsFixed(1).replaceAll('.', ',')} m';
  static String _s(double v) => '${v.toStringAsFixed(1).replaceAll('.', ',')} s';
  static String _c(double v) => '${v.toStringAsFixed(1).replaceAll('.', ',')} °C';
}

/// Pomocnicze: iloczyn mnożników (do testów / diagnostyki).
double productOfMultipliers(Iterable<VisibilityFactor> factors) =>
    factors.fold(1.0, (p, f) => p * f.multiplier);

/// Pomocnicze: zaokrąglenie do 0.1 z obcięciem (do testów).
double clampAndRound(double v) {
  final c = v.clamp(VisibilityCalculator.minVisibility,
      VisibilityCalculator.maxVisibility);
  return (c * 10).round() / 10;
}
