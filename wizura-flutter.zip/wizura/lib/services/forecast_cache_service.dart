import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/spot_forecast.dart';

/// Zapis prognoz w [SharedPreferences], aby aplikacja działała offline.
class ForecastCacheService {
  ForecastCacheService();

  static const String _key = 'wizura_forecast_cache_v1';

  Future<CachedForecasts?> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return null;
    try {
      final decoded = json.decode(raw) as Map<String, dynamic>;
      final savedAt = DateTime.parse(decoded['savedAt'] as String);
      final map = <String, SpotForecast>{};
      final forecasts = decoded['forecasts'] as Map<String, dynamic>;
      for (final entry in forecasts.entries) {
        map[entry.key] =
            SpotForecast.fromJson(entry.value as Map<String, dynamic>);
      }
      return CachedForecasts(savedAt: savedAt, forecasts: map);
    } catch (_) {
      await prefs.remove(_key);
      return null;
    }
  }

  Future<void> save(Map<String, SpotForecast> forecasts, DateTime savedAt) async {
    final prefs = await SharedPreferences.getInstance();
    final payload = {
      'savedAt': savedAt.toIso8601String(),
      'forecasts': {
        for (final e in forecasts.entries) e.key: e.value.toJson(),
      },
    };
    await prefs.setString(_key, json.encode(payload));
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}

class CachedForecasts {
  const CachedForecasts({required this.savedAt, required this.forecasts});
  final DateTime savedAt;
  final Map<String, SpotForecast> forecasts;
}
