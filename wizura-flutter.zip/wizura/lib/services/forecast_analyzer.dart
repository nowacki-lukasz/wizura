import 'dart:math' as math;

import '../models/diving_spot.dart';
import '../models/hour_data.dart';
import '../models/spot_analysis.dart';
import '../models/spot_forecast.dart';
import '../models/time_block.dart';
import '../models/visibility_estimate.dart';
import '../utils/angle_utils.dart';
import '../utils/format_utils.dart';
import 'visibility_calculator.dart';

/// Zamienia surowe dane godzinowe w bloki 6-godzinne, dni i rekomendacje.
class ForecastAnalyzer {
  const ForecastAnalyzer({this.calculator = const VisibilityCalculator()});

  final VisibilityCalculator calculator;

  static const int daysCount = 5;
  static const int blockHours = 6;

  SpotAnalysis analyze(DivingSpot spot, SpotForecast forecast, {DateTime? now}) {
    final n = now ?? DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final hours = forecast.hours;

    final blocks = <TimeBlock>[];
    for (var d = 0; d < daysCount; d++) {
      for (var b = 0; b < 24 ~/ blockHours; b++) {
        final start = today.add(Duration(days: d, hours: b * blockHours));
        final end = start.add(const Duration(hours: blockHours));
        final conditions = buildConditions(hours, start, end, forecast);
        final estimate = calculator.estimate(
          spot: spot,
          c: conditions,
          time: start,
        );
        blocks.add(TimeBlock(
          start: start,
          end: end,
          conditions: conditions,
          estimate: estimate,
        ));
      }
    }

    final days = <DayAnalysis>[];
    for (var d = 0; d < daysCount; d++) {
      days.add(DayAnalysis(
        date: today.add(Duration(days: d)),
        blocks: blocks.sublist(d * 4, d * 4 + 4),
      ));
    }

    final current = blocks.firstWhere(
      (b) => b.contains(n),
      orElse: () => blocks.first,
    );

    final recommendations = [
      for (final day in days) buildRecommendation(spot, day, forecast),
    ];

    return SpotAnalysis(
      spot: spot,
      forecast: forecast,
      blocks: blocks,
      days: days,
      current: current,
      recommendations: recommendations,
    );
  }

  /// Uśrednia godziny z przedziału [start, end) i liczy wskaźniki historyczne.
  BlockConditions buildConditions(
    List<HourData> hours,
    DateTime start,
    DateTime end,
    SpotForecast forecast,
  ) {
    final inBlock = hours
        .where((h) => !h.time.isBefore(start) && h.time.isBefore(end))
        .toList();

    final prev24 = hours.where((h) =>
        !h.time.isBefore(start.subtract(const Duration(hours: 24))) &&
        h.time.isBefore(start));
    final prev72 = hours.where((h) =>
        !h.time.isBefore(start.subtract(const Duration(hours: 72))) &&
        h.time.isBefore(start));
    final around48 = hours.where((h) =>
        !h.time.isBefore(start.subtract(const Duration(hours: 54))) &&
        h.time.isBefore(start.subtract(const Duration(hours: 42))));

    final maxWave24 = _max(prev24.map((h) => h.waveHeight));
    final rain72 = _sum(prev72.map((h) => h.precipitation));
    final sst48 = _mean(around48.map((h) => h.seaSurfaceTemperature));

    final vistula = forecast.vistula;

    return BlockConditions(
      windSpeed: _mean(inBlock.map((h) => h.windSpeed)),
      windGusts: _max(inBlock.map((h) => h.windGusts)),
      windDirection: AngleUtils.circularMean(
          inBlock.map((h) => h.windDirection).whereType<double>()),
      waveHeight: _mean(inBlock.map((h) => h.waveHeight)),
      wavePeriod: _mean(inBlock.map((h) => h.wavePeriod)),
      waveDirection: AngleUtils.circularMean(
          inBlock.map((h) => h.waveDirection).whereType<double>()),
      windWaveHeight: _mean(inBlock.map((h) => h.windWaveHeight)),
      swellWaveHeight: _mean(inBlock.map((h) => h.swellWaveHeight)),
      seaSurfaceTemperature: _mean(inBlock.map((h) => h.seaSurfaceTemperature)),
      seaSurfaceTemperature48hAgo: sst48,
      precipitation72h: rain72,
      maxWaveHeight24h: maxWave24,
      vistulaLevelCm: vistula?.waterLevelCm,
      vistulaFlowM3s: vistula?.flowM3s,
      vistulaWarningLevelCm: vistula?.warningLevelCm,
    );
  }

  /// Ocena typu wejścia i rekomendacja nurkowa dla dnia.
  Recommendation buildRecommendation(
      DivingSpot spot, DayAnalysis day, SpotForecast forecast) {
    final best = day.bestBlock;
    final c = best.conditions;
    final wave = c.waveHeight ??
        (c.effectiveWindSpeed == null
            ? null
            : VisibilityCalculator.estimateWaveFromWind(c.effectiveWindSpeed!));
    final wind = c.effectiveWindSpeed;
    final gusts = c.windGusts;
    final warnings = <String>[];

    // Maksymalna fala / wiatr w ciągu całego dnia (dla ostrzeżeń).
    final dayMaxWave = _max(day.blocks.map((b) => b.conditions.waveHeight));
    final dayMaxGust = _max(day.blocks.map((b) => b.conditions.windGusts));

    final String entry;
    switch (spot.entryType) {
      case EntryType.shore:
        if (wave == null) {
          entry = 'Wejście z brzegu – brak danych o fali';
        } else if (wave < 0.4) {
          entry = 'Wejście z brzegu – bezpieczne';
        } else if (wave < 0.8) {
          entry = 'Wejście z brzegu – utrudnione (fala przybojowa)';
          warnings.add(
              'Fala ${FormatUtils.meters(wave)} rozbija się na brzegu – wchodź i wychodź ze sprzętem zabezpieczonym, w parze.');
        } else {
          entry = 'Wejście z brzegu – niebezpieczne';
          warnings.add(
              'Fala ${FormatUtils.meters(wave)} – wejście z brzegu odradzane, ryzyko przewrócenia w przyboju.');
        }
      case EntryType.boat:
        if (wave == null) {
          entry = 'Konieczna łódź – brak danych o fali';
        } else if (wave < 0.6 && (wind ?? 0) < 30) {
          entry = 'Konieczna łódź – warunki dobre do wyjścia';
        } else if (wave < 1.0 && (wind ?? 0) < 40) {
          entry = 'Konieczna łódź – wyjście możliwe, będzie bujać';
          warnings.add(
              'Fala ${FormatUtils.meters(wave)} – wyjście łodzią możliwe, ale dekompresja na boi może być uciążliwa.');
        } else {
          entry = 'Konieczna łódź – wyjście ryzykowne';
          warnings.add(
              'Fala ${FormatUtils.meters(wave)}${wind != null ? ', wiatr ${FormatUtils.kmh(wind)}' : ''} – większość skipperów odwoła wyjście.');
        }
      case EntryType.shoreOrBoat:
        if (wave == null) {
          entry = 'Brzeg lub łódź – brak danych o fali';
        } else if (wave < 0.4) {
          entry = 'Możliwe wejście z brzegu (lub łódź)';
        } else if (wave < 0.8) {
          entry = 'Zalecana łódź – z brzegu trudno przez przybój';
        } else {
          entry = 'Tylko łódź, a i to ryzykowne';
          warnings.add('Fala ${FormatUtils.meters(wave)} – wejście z brzegu odradzane.');
        }
    }

    if (spot.isDeep) {
      warnings.add(
          'Nurkowanie techniczne (${spot.depthLabel}) – wymagane uprawnienia trimix i dekompresja etapowa.');
    }

    if (dayMaxGust != null && dayMaxGust >= 50) {
      warnings.add(
          'Porywy wiatru do ${FormatUtils.kmh(dayMaxGust)} w ciągu dnia – warunki mogą się szybko zmieniać.');
    }
    if (dayMaxWave != null && dayMaxWave >= 1.5 && (wave ?? 0) < 0.8) {
      warnings.add(
          'W ciągu dnia fala rośnie do ${FormatUtils.meters(dayMaxWave)} – planuj nurkowanie w oknie ${best.hourLabel}.');
    }
    if (c.precipitation72h != null && c.precipitation72h! > 15) {
      warnings.add(
          'Po opadach (${c.precipitation72h!.round()} mm / 72 h) spływ z lądu może lokalnie pogorszyć wizurę.');
    }
    final v = forecast.vistula;
    if (spot.vistulaInfluence >= 0.5 && v != null && v.waterLevelCm != null) {
      final warn = v.warningLevelCm ?? 700;
      if (v.waterLevelCm! / warn > 0.5) {
        warnings.add(
            'Wisła w Tczewie: ${v.waterLevelCm!.round()} cm (ostrzegawczy ${warn.round()} cm) – smuga zawiesiny przy ujściu.');
      }
    }

    final vis = best.estimate.meters;
    final cat = best.estimate.category;
    final windTxt = wind == null
        ? ''
        : ', wiatr ${AngleUtils.compassName(c.windDirection ?? 0)} ${FormatUtils.kmh(wind)}${gusts != null && gusts > wind + 10 ? ' (porywy ${FormatUtils.kmh(gusts)})' : ''}';
    final waveTxt = wave == null ? '' : ', fala ${FormatUtils.meters(wave)}';

    final String summary;
    switch (cat) {
      case ConditionCategory.good:
        summary =
            'Warto jechać. Najlepsze okno ${best.hourLabel} – wizura ok. ${FormatUtils.meters(vis)}$waveTxt$windTxt.';
      case ConditionCategory.medium:
        summary =
            'Nurkowanie możliwe, ale bez fajerwerków. Najlepsze okno ${best.hourLabel} – wizura ok. ${FormatUtils.meters(vis)}$waveTxt$windTxt. Trzymaj się blisko partnera.';
      case ConditionCategory.poor:
        summary =
            'Odpuść ten dzień. Nawet w najlepszym oknie (${best.hourLabel}) wizura ok. ${FormatUtils.meters(vis)}$waveTxt$windTxt – "mleko".';
    }

    return Recommendation(
      entryAssessment: entry,
      summary: summary,
      warnings: warnings,
    );
  }

  // ---------------------------------------------------------------- utils
  static double? _mean(Iterable<double?> values) {
    var sum = 0.0;
    var n = 0;
    for (final v in values) {
      if (v == null) continue;
      sum += v;
      n++;
    }
    return n == 0 ? null : sum / n;
  }

  static double? _max(Iterable<double?> values) {
    double? m;
    for (final v in values) {
      if (v == null) continue;
      m = m == null ? v : math.max(m, v);
    }
    return m;
  }

  static double? _sum(Iterable<double?> values) {
    var sum = 0.0;
    var n = 0;
    for (final v in values) {
      if (v == null) continue;
      sum += v;
      n++;
    }
    return n == 0 ? null : sum;
  }
}
