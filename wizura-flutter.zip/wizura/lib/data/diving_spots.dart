import '../models/diving_spot.dart';

/// Baza 10 spotów nurkowych Zatoki Gdańskiej (zapisana na sztywno).
const List<DivingSpot> divingSpots = [
  DivingSpot(
    id: 'bryza',
    name: 'ORP Bryza (Hel)',
    latitude: 54.6042,
    longitude: 18.8021,
    depthLabel: '11-21m',
    minDepth: 11,
    maxDepth: 21,
    shoreFacingAngle: 225,
    entryType: EntryType.boat,
    description:
        'Wrak trałowca ORP Bryza zatopiony jako sztuczna rafa u wybrzeży Helu. '
        'Leży na głębokości ok. 21 m, pokład na 11-15 m. Wymaga wyjścia łodzią z portu Hel.',
    vistulaInfluence: 0.15,
  ),
  DivingSpot(
    id: 'kujawiak',
    name: 'Cypel Helski / Wrak Kujawiak',
    latitude: 54.5950,
    longitude: 18.8250,
    depthLabel: '4-6m',
    minDepth: 4,
    maxDepth: 6,
    shoreFacingAngle: 135,
    entryType: EntryType.shoreOrBoat,
    description:
        'Płytkie nurkowanie przy cyplu Półwyspu Helskiego. Piaszczyste dno, '
        'silne prądy przy zmianie wiatru. Płytkie fragmenty wraku i konstrukcje.',
    vistulaInfluence: 0.15,
  ),
  DivingSpot(
    id: 'babie-doly',
    name: 'Torpedownia Babie Doły',
    latitude: 54.5878,
    longitude: 18.5458,
    depthLabel: '1-9m',
    minDepth: 1,
    maxDepth: 9,
    shoreFacingAngle: 80,
    entryType: EntryType.shore,
    description:
        'Ruiny niemieckiej torpedowni z II wojny światowej, ok. 300 m od plaży. '
        'Wejście z brzegu, dopłynięcie po powierzchni. Betonowe konstrukcje i pale.',
    vistulaInfluence: 0.3,
  ),
  DivingSpot(
    id: 'orlowo',
    name: 'Klif Orłowo / Kamienie',
    latitude: 54.4811,
    longitude: 18.5658,
    depthLabel: '2-5m',
    minDepth: 2,
    maxDepth: 5,
    shoreFacingAngle: 90,
    entryType: EntryType.shore,
    description:
        'Kamieniste dno pod klifem orłowskim. Dużo życia (babki, krewetki, omułki). '
        'Bardzo wrażliwe na fale ze wschodu – szybko robi się "mleko".',
    vistulaInfluence: 0.3,
  ),
  DivingSpot(
    id: 'formoza',
    name: 'Torpedownia Oksywie (Formoza)',
    latitude: 54.5447,
    longitude: 18.5539,
    depthLabel: '3-8m',
    minDepth: 3,
    maxDepth: 8,
    shoreFacingAngle: 90,
    entryType: EntryType.shore,
    description:
        'Torpedownia "Formoza" przy Oksywiu. Konstrukcje betonowe i stalowe, '
        'dużo ryb. Uwaga na ruch jednostek i strefę wojskową – sprawdź aktualne zakazy.',
    vistulaInfluence: 0.3,
  ),
  DivingSpot(
    id: 'rewa',
    name: 'Rewa (Cypel / Szpyrk)',
    latitude: 54.6331,
    longitude: 18.5133,
    depthLabel: '1-12m',
    minDepth: 1,
    maxDepth: 12,
    shoreFacingAngle: 70,
    entryType: EntryType.shore,
    description:
        'Cypel Rewski (Szpyrk) – piaszczysta mierzeja z uskokiem dna w stronę Zatoki Puckiej. '
        'Łatwe wejście z brzegu, warto uważać na prąd wzdłuż cypla.',
    vistulaInfluence: 0.15,
  ),
  DivingSpot(
    id: 'mechelinki',
    name: 'Mechelinki Rafa',
    latitude: 54.6105,
    longitude: 18.5186,
    depthLabel: '3-7m',
    minDepth: 3,
    maxDepth: 7,
    shoreFacingAngle: 80,
    entryType: EntryType.shore,
    description:
        'Sztuczna rafa (kamienne konstrukcje) w Mechelinkach, przy nowym molo. '
        'Dobre miejsce na nurkowanie nocne i szkoleniowe.',
    vistulaInfluence: 0.15,
  ),
  DivingSpot(
    id: 'sopot',
    name: 'Molo Sopot / Rafka',
    latitude: 54.4485,
    longitude: 18.5742,
    depthLabel: '3-6m',
    minDepth: 3,
    maxDepth: 6,
    shoreFacingAngle: 90,
    entryType: EntryType.shore,
    description:
        'Sztuczna rafa na wysokości molo w Sopocie oraz pale samego mola. '
        'Popularne miejsce na "pierwsze nurkowanie w Bałtyku". Duży ruch turystów latem.',
    vistulaInfluence: 0.3,
  ),
  DivingSpot(
    id: 'gorki-zachodnie',
    name: 'Górki Zachodnie (Ujście Wisły)',
    latitude: 54.3688,
    longitude: 18.7844,
    depthLabel: '2-8m',
    minDepth: 2,
    maxDepth: 8,
    shoreFacingAngle: 0,
    entryType: EntryType.shore,
    description:
        'Okolice ujścia Martwej Wisły (Wisły Śmiałej). Wizura zależy przede wszystkim '
        'od ilości wody i zawiesiny niesionej rzeką – po ulewach i wysokim stanie Wisły nurkowanie nie ma sensu.',
    vistulaInfluence: 1.0,
  ),
  DivingSpot(
    id: 'franken',
    name: 'Wrak Franken (Trawers)',
    latitude: 54.5367,
    longitude: 18.8500,
    depthLabel: '47-72m',
    minDepth: 47,
    maxDepth: 72,
    shoreFacingAngle: -1,
    entryType: EntryType.boat,
    description:
        'Niemiecki tankowiec zaopatrzeniowy Franken – jeden z największych wraków Bałtyku. '
        'Nurkowanie techniczne (trimix), wyłącznie z łodzi. Poniżej termokliny wizura bywa znacznie lepsza niż przy brzegu.',
    vistulaInfluence: 0.1,
  ),
];

DivingSpot spotById(String id) => divingSpots.firstWhere((s) => s.id == id);
