import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:latlong2/latlong.dart';

import '../models/spot_analysis.dart';
import '../providers/forecast_providers.dart';
import '../utils/format_utils.dart';
import '../widgets/spot_quick_sheet.dart';
import 'spot_detail_view.dart';

/// Mapa OpenStreetMap z kolorowymi markerami 10 spotów.
class SpotMapView extends ConsumerStatefulWidget {
  const SpotMapView({super.key});

  @override
  ConsumerState<SpotMapView> createState() => _SpotMapViewState();
}

class _SpotMapViewState extends ConsumerState<SpotMapView> {
  final MapController _controller = MapController();

  static const LatLng _center = LatLng(54.52, 18.66);
  static const double _zoom = 10.2;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final spots = ref.watch(spotsProvider);
    final analyses = {
      for (final a in ref.watch(allAnalysesProvider)) a.spot.id: a,
    };
    final theme = Theme.of(context);

    return Stack(
      children: [
        FlutterMap(
          mapController: _controller,
          options: const MapOptions(
            initialCenter: _center,
            initialZoom: _zoom,
            minZoom: 8,
            maxZoom: 17,
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'eu.neoteric.wizura',
            ),
            MarkerLayer(
              markers: [
                for (final spot in spots)
                  Marker(
                    point: LatLng(spot.latitude, spot.longitude),
                    width: 64,
                    height: 64,
                    alignment: Alignment.topCenter,
                    child: _SpotMarker(
                      analysis: analyses[spot.id],
                      onTap: () => _openSheet(context, analyses[spot.id]),
                    ),
                  ),
              ],
            ),
            const RichAttributionWidget(
              attributions: [
                TextSourceAttribution('OpenStreetMap contributors'),
              ],
            ),
          ],
        ),
        Positioned(
          right: 12,
          bottom: 12,
          child: FloatingActionButton.small(
            heroTag: 'recenter',
            tooltip: 'Wycentruj mapę',
            onPressed: () => _controller.move(_center, _zoom),
            child: const Icon(Icons.center_focus_strong),
          ),
        ),
        Positioned(
          left: 12,
          top: 12,
          child: Material(
            color: theme.colorScheme.surface.withValues(alpha: 0.9),
            borderRadius: BorderRadius.circular(10),
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _LegendDot(color: Color(0xFF2E9E4F), label: '> 4 m'),
                  SizedBox(width: 8),
                  _LegendDot(color: Color(0xFFE0A100), label: '2–4 m'),
                  SizedBox(width: 8),
                  _LegendDot(color: Color(0xFFD63B2F), label: '< 2 m'),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _openSheet(BuildContext context, SpotAnalysis? analysis) {
    if (analysis == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Brak danych dla tego spotu – odśwież prognozę.')),
      );
      return;
    }
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: false,
      isScrollControlled: true,
      builder: (ctx) => SpotQuickSheet(
        analysis: analysis,
        onOpenDetails: () {
          Navigator.of(ctx).pop();
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => SpotDetailView(spotId: analysis.spot.id),
            ),
          );
        },
      ),
    );
  }
}

class _SpotMarker extends StatelessWidget {
  const _SpotMarker({required this.analysis, required this.onTap});

  final SpotAnalysis? analysis;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = analysis?.current.estimate.category.color ?? Colors.grey;
    final text = analysis == null
        ? '?'
        : FormatUtils.meters(analysis!.current.estimate.meters).replaceAll(' m', '');
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2.5),
              boxShadow: const [
                BoxShadow(color: Colors.black38, blurRadius: 4, offset: Offset(0, 2)),
              ],
            ),
            alignment: Alignment.center,
            child: Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
          ),
          Transform.translate(
            offset: const Offset(0, -7),
            child: Icon(Icons.arrow_drop_down, color: color, size: 24),
          ),
        ],
      ),
    );
  }
}

class _LegendDot extends StatelessWidget {
  const _LegendDot({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 4),
        Text(label, style: Theme.of(context).textTheme.labelSmall),
      ],
    );
  }
}
