import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/spot_analysis.dart';
import '../providers/forecast_providers.dart';
import '../widgets/spot_card.dart';
import 'spot_detail_view.dart';

/// Lista 10 spotów z badge'em wizury (pull-to-refresh).
class SpotListView extends ConsumerWidget {
  const SpotListView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final forecasts = ref.watch(forecastsProvider);
    final analyses = ref.watch(allAnalysesProvider);
    final sort = ref.watch(spotSortProvider);

    if (analyses.isEmpty) {
      if (forecasts.isLoading) {
        return const _LoadingView();
      }
      if (forecasts.hasError) {
        return _ErrorView(
          message: forecasts.error.toString().replaceFirst('OpenMeteoException: ', ''),
          onRetry: () => ref.read(forecastsProvider.notifier).refresh(),
        );
      }
    }

    final sorted = List<SpotAnalysis>.of(analyses);
    if (sort == SpotSort.byVisibility) {
      sorted.sort((a, b) =>
          b.current.estimate.meters.compareTo(a.current.estimate.meters));
    }

    return RefreshIndicator(
      onRefresh: () => ref.read(forecastsProvider.notifier).refresh(),
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(top: 6, bottom: 24),
        itemCount: sorted.length + 1,
        itemBuilder: (context, i) {
          if (i == sorted.length) return const _Legend();
          final a = sorted[i];
          return SpotCard(
            analysis: a,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => SpotDetailView(spotId: a.spot.id),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _LoadingView extends StatelessWidget {
  const _LoadingView();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 16),
          Text('Pobieram prognozę fali i wiatru dla 10 spotów…'),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.cloud_off, size: 48, color: Theme.of(context).colorScheme.error),
            const SizedBox(height: 16),
            const Text(
              'Nie udało się pobrać prognozy',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('Spróbuj ponownie'),
            ),
          ],
        ),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend();

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context)
        .textTheme
        .labelSmall
        ?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
      child: Text(
        'Badge = wizura dla bieżącego bloku 6 h. Kropki = 4 bloki dnia (00–06, 06–12, 12–18, 18–24). '
        'Zielony > 4 m, żółty 2–4 m, czerwony < 2 m. Strzałka pokazuje, dokąd wieje wiatr.',
        style: style,
      ),
    );
  }
}
