import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/diving_spot.dart';
import '../models/spot_analysis.dart';
import '../providers/forecast_providers.dart';
import '../utils/angle_utils.dart';
import '../utils/format_utils.dart';
import '../widgets/block_row.dart';
import '../widgets/factor_breakdown.dart';
import '../widgets/metric_chip.dart';
import '../widgets/visibility_badge.dart';
import '../widgets/visibility_chart.dart';
import '../widgets/wind_arrow.dart';

/// Ekran szczegółów spotu: prognoza 5 dni w blokach 6 h, czynniki, rekomendacje.
class SpotDetailView extends ConsumerStatefulWidget {
  const SpotDetailView({super.key, required this.spotId});

  final String spotId;

  @override
  ConsumerState<SpotDetailView> createState() => _SpotDetailViewState();
}

class _SpotDetailViewState extends ConsumerState<SpotDetailView> {
  int? _selectedBlock;

  @override
  Widget build(BuildContext context) {
    final analysis = ref.watch(spotAnalysisProvider(widget.spotId));
    final spot = ref.watch(spotsProvider).firstWhere((s) => s.id == widget.spotId);

    if (analysis == null) {
      return Scaffold(
        appBar: AppBar(title: Text(spot.name)),
        body: const Center(child: Text('Brak danych – odśwież prognozę na liście.')),
      );
    }

    final selectedIndex =
        _selectedBlock ?? analysis.blocks.indexOf(analysis.current);
    final selected = analysis.blocks[selectedIndex];
    final dayIndex = selectedIndex ~/ 4;
    final day = analysis.days[dayIndex];
    final rec = analysis.recommendations[dayIndex];
    final theme = Theme.of(context);

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () => ref.read(forecastsProvider.notifier).refresh(),
        child: CustomScrollView(
          slivers: [
            SliverAppBar.medium(
              title: Text(spot.name),
              pinned: true,
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
              sliver: SliverList.list(
                children: [
                  _Header(analysis: analysis, spot: spot),
                  const SizedBox(height: 20),
                  _SectionTitle('Prognoza wizury – 5 dni (bloki 6 h)'),
                  const SizedBox(height: 4),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(8, 12, 12, 8),
                      child: VisibilityChart(
                        blocks: analysis.blocks,
                        selectedIndex: selectedIndex,
                        onSelect: (i) => setState(() => _selectedBlock = i),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _DaySelector(
                    days: analysis.days,
                    selectedDay: dayIndex,
                    onSelect: (d) => setState(() {
                      // Wybierz najlepszy blok dnia albo bieżący, jeśli to dziś.
                      final blocks = analysis.days[d].blocks;
                      final now = DateTime.now();
                      final nowBlock = blocks.where((b) => b.contains(now));
                      final target = nowBlock.isNotEmpty
                          ? nowBlock.first
                          : analysis.days[d].bestBlock;
                      _selectedBlock = analysis.blocks.indexOf(target);
                    }),
                  ),
                  const SizedBox(height: 8),
                  Card(
                    child: Column(
                      children: [
                        for (final b in day.blocks)
                          BlockRow(
                            block: b,
                            selected: b == selected,
                            isNow: b == analysis.current,
                            onTap: () => setState(
                                () => _selectedBlock = analysis.blocks.indexOf(b)),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  _SectionTitle(
                    'Dlaczego ${FormatUtils.meters(selected.estimate.meters)}? '
                    '(${FormatUtils.relativeDay(selected.start)} ${selected.hourLabel})',
                  ),
                  const SizedBox(height: 4),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: FactorBreakdown(estimate: selected.estimate),
                    ),
                  ),
                  const SizedBox(height: 20),
                  _SectionTitle('Wejście i rekomendacja – ${FormatUtils.relativeDay(day.date)}'),
                  const SizedBox(height: 4),
                  _RecommendationCard(spot: spot, recommendation: rec, day: day),
                  const SizedBox(height: 20),
                  _SectionTitle('O spocie'),
                  const SizedBox(height: 4),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(spot.description, style: theme.textTheme.bodyMedium),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 16,
                            runSpacing: 8,
                            children: [
                              MetricChip(
                                icon: Icons.straighten,
                                value: spot.depthLabel,
                                label: 'głębokość',
                              ),
                              MetricChip(
                                icon: Icons.explore,
                                value: spot.isOpenWater
                                    ? 'otwarte morze'
                                    : '${spot.shoreFacingAngle.round()}° (${AngleUtils.compassName(spot.shoreFacingAngle)})',
                                label: 'ekspozycja brzegu',
                              ),
                              MetricChip(
                                icon: Icons.place,
                                value:
                                    '${spot.latitude.toStringAsFixed(4)}, ${spot.longitude.toStringAsFixed(4)}',
                                label: 'współrzędne',
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          _DataSources(analysis: analysis),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.analysis, required this.spot});

  final SpotAnalysis analysis;
  final DivingSpot spot;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final current = analysis.current;
    final c = current.conditions;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Teraz (${FormatUtils.relativeDay(current.start)} ${current.hourLabel})',
                        style: theme.textTheme.labelLarge
                            ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        current.estimate.category.label,
                        style: theme.textTheme.titleLarge?.copyWith(
                          color: current.estimate.category.color,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${spot.depthLabel} · ${spot.entryType.label}',
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                      ),
                    ],
                  ),
                ),
                VisibilityBadge(meters: current.estimate.meters, large: true),
              ],
            ),
            const Divider(height: 24),
            Wrap(
              spacing: 20,
              runSpacing: 10,
              children: [
                MetricChip(
                  icon: Icons.air,
                  value: '',
                  label: 'wiatr (porywy)',
                  child: WindArrow(
                    directionFrom: c.windDirection,
                    speedKmh: c.effectiveWindSpeed,
                    gustsKmh: c.windGusts,
                  ),
                ),
                MetricChip(
                  icon: Icons.waves,
                  value: c.waveHeight == null
                      ? 'brak danych'
                      : '${FormatUtils.meters(c.waveHeight!)}${c.wavePeriod == null ? '' : ' / ${FormatUtils.seconds(c.wavePeriod!)}'}${c.waveDirection == null ? '' : ' ${AngleUtils.compassName(c.waveDirection!)}'}',
                  label: 'fala / okres / kierunek',
                ),
                if (c.seaSurfaceTemperature != null)
                  MetricChip(
                    icon: Icons.thermostat,
                    value: FormatUtils.celsius(c.seaSurfaceTemperature!),
                    label: 'temperatura wody',
                  ),
                if (c.maxWaveHeight24h != null)
                  MetricChip(
                    icon: Icons.history,
                    value: FormatUtils.meters(c.maxWaveHeight24h!),
                    label: 'max fala 24 h wstecz',
                  ),
                if (c.precipitation72h != null)
                  MetricChip(
                    icon: Icons.umbrella,
                    value: '${c.precipitation72h!.round()} mm',
                    label: 'opad 72 h',
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _DaySelector extends StatelessWidget {
  const _DaySelector({
    required this.days,
    required this.selectedDay,
    required this.onSelect,
  });

  final List<DayAnalysis> days;
  final int selectedDay;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (var i = 0; i < days.length; i++)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                selected: i == selectedDay,
                onSelected: (_) => onSelect(i),
                avatar: ConditionDot(meters: days[i].maxVisibility, size: 12),
                label: Text(
                  '${FormatUtils.relativeDay(days[i].date)} · ${FormatUtils.meters(days[i].maxVisibility)}',
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _RecommendationCard extends StatelessWidget {
  const _RecommendationCard({
    required this.spot,
    required this.recommendation,
    required this.day,
  });

  final DivingSpot spot;
  final Recommendation recommendation;
  final DayAnalysis day;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cat = day.category;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  spot.entryType == EntryType.boat
                      ? Icons.directions_boat
                      : Icons.beach_access,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    recommendation.entryAssessment,
                    style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: cat.color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: cat.color.withValues(alpha: 0.5)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.scuba_diving, color: cat.color),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(recommendation.summary, style: theme.textTheme.bodyMedium),
                  ),
                ],
              ),
            ),
            for (final w in recommendation.warnings)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.warning_amber_rounded,
                        size: 18, color: theme.colorScheme.error),
                    const SizedBox(width: 8),
                    Expanded(child: Text(w, style: theme.textTheme.bodySmall)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _DataSources extends StatelessWidget {
  const _DataSources({required this.analysis});

  final SpotAnalysis analysis;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final v = analysis.forecast.vistula;
    final style = theme.textTheme.labelSmall
        ?.copyWith(color: theme.colorScheme.onSurfaceVariant);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Źródła danych', style: theme.textTheme.labelLarge),
        const SizedBox(height: 4),
        Text(
          'Fala, okres, kierunek, temperatura wody: Open-Meteo Marine API. '
          'Wiatr, porywy, opady: Open-Meteo Weather API. '
          'Pobrano: ${FormatUtils.dateTime(analysis.forecast.fetchedAt)}.',
          style: style,
        ),
        const SizedBox(height: 4),
        Text(
          v == null
              ? 'Stan Wisły (IMGW-PIB, Tczew): brak danych – czynnik pominięty.'
              : 'Stan Wisły (IMGW-PIB, ${v.stationName}): ${v.waterLevelCm?.round() ?? '—'} cm'
                  '${v.flowM3s == null ? '' : ', ${v.flowM3s!.round()} m³/s'}'
                  '${v.measuredAt == null ? '' : ' (${FormatUtils.dateTime(v.measuredAt!)})'}.',
          style: style,
        ),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .titleMedium
            ?.copyWith(fontWeight: FontWeight.w600),
      ),
    );
  }
}
