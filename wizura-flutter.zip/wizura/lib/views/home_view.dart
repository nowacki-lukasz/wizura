import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/forecast_providers.dart';
import '../utils/format_utils.dart';
import '../widgets/offline_banner.dart';
import 'spot_list_view.dart';
import 'spot_map_view.dart';

/// Ekran główny: przełącznik Lista / Mapa + pasek stanu danych.
class HomeView extends ConsumerStatefulWidget {
  const HomeView({super.key});

  @override
  ConsumerState<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends ConsumerState<HomeView> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final forecasts = ref.watch(forecastsProvider);
    final state = forecasts.valueOrNull;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Wizura – Zatoka Gdańska'),
            if (state != null)
              Text(
                'Aktualizacja: ${FormatUtils.dateTime(state.updatedAt)}',
                style: theme.textTheme.labelSmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
          ],
        ),
        actions: [
          if (_tab == 0)
            PopupMenuButton<SpotSort>(
              icon: const Icon(Icons.sort),
              tooltip: 'Sortowanie',
              initialValue: ref.watch(spotSortProvider),
              onSelected: (v) => ref.read(spotSortProvider.notifier).state = v,
              itemBuilder: (_) => const [
                PopupMenuItem(
                  value: SpotSort.defaultOrder,
                  child: Text('Kolejność domyślna'),
                ),
                PopupMenuItem(
                  value: SpotSort.byVisibility,
                  child: Text('Najlepsza wizura na górze'),
                ),
              ],
            ),
          IconButton(
            tooltip: 'Odśwież prognozę',
            icon: forecasts.isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh),
            onPressed: forecasts.isLoading
                ? null
                : () => ref.read(forecastsProvider.notifier).refresh(),
          ),
          IconButton(
            tooltip: 'O aplikacji',
            icon: const Icon(Icons.info_outline),
            onPressed: () => _showAbout(context),
          ),
        ],
      ),
      body: Column(
        children: [
          if (state != null &&
              (state.isOffline ||
                  state.partialErrors.isNotEmpty ||
                  (state.fromCache &&
                      DateTime.now().difference(state.updatedAt) >
                          const Duration(hours: 1))))
            OfflineBanner(
              updatedAt: state.updatedAt,
              reason: state.offlineReason,
              partialErrorCount: state.partialErrors.length,
              onRetry: state.isOffline
                  ? () => ref.read(forecastsProvider.notifier).refresh()
                  : null,
            ),
          Expanded(
            child: IndexedStack(
              index: _tab,
              children: const [
                SpotListView(),
                SpotMapView(),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.view_list_outlined),
            selectedIcon: Icon(Icons.view_list),
            label: 'Lista',
          ),
          NavigationDestination(
            icon: Icon(Icons.map_outlined),
            selectedIcon: Icon(Icons.map),
            label: 'Mapa',
          ),
        ],
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('O aplikacji'),
        content: const SingleChildScrollView(
          child: Text(
            'Wizura szacuje widoczność podwodną dla 10 spotów w Zatoce Gdańskiej '
            'na podstawie prognozy fali i wiatru (Open-Meteo Marine & Weather API), '
            'opadów z ostatnich 72 h, temperatury wody oraz stanu Wisły w Tczewie (IMGW-PIB).\n\n'
            'Algorytm działa w całości na telefonie. Wynik to estymacja statystyczna – '
            'zawsze oceniaj warunki na miejscu.\n\n'
            'Kolory:\n'
            '• zielony – wizura > 4 m (dobre warunki)\n'
            '• żółty – 2–4 m (średnie warunki)\n'
            '• czerwony – < 2 m (słaba wizura / „mleko”)\n\n'
            'Dane: open-meteo.com (CC BY 4.0), danepubliczne.imgw.pl, mapa © OpenStreetMap contributors.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Zamknij'),
          ),
        ],
      ),
    );
  }
}
