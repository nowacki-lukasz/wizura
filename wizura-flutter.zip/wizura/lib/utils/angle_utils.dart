import 'dart:math' as math;

/// Narzędzia do arytmetyki kątów (kierunki wiatru / fali / brzegu).
class AngleUtils {
  AngleUtils._();

  /// Najmniejsza różnica kątowa między dwoma kierunkami (0–180°).
  static double difference(double a, double b) {
    final diff = ((a - b) % 360 + 360) % 360;
    return diff > 180 ? 360 - diff : diff;
  }

  /// Średnia kołowa kierunków (w stopniach, 0–360).
  /// Zwraca `null`, jeśli lista jest pusta.
  static double? circularMean(Iterable<double> degrees) {
    var sx = 0.0;
    var sy = 0.0;
    var n = 0;
    for (final d in degrees) {
      final r = d * math.pi / 180;
      sx += math.cos(r);
      sy += math.sin(r);
      n++;
    }
    if (n == 0) return null;
    if (sx.abs() < 1e-9 && sy.abs() < 1e-9) return 0;
    final mean = math.atan2(sy, sx) * 180 / math.pi;
    final normalized = (mean + 360) % 360;
    // Zabezpieczenie przed 359.9999999 wynikającym z błędów zaokrągleń.
    return normalized >= 360 - 1e-9 ? 0 : normalized;
  }

  /// Nazwa kierunku (16 rumbów), np. 225 -> "SW".
  static String compassName(double degrees) {
    const names = [
      'N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
      'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW',
    ];
    final idx = (((degrees % 360) + 360) % 360 / 22.5).round() % 16;
    return names[idx];
  }

  /// Polska nazwa kierunku (8 rumbów), np. 225 -> "południowo-zachodni".
  static String polishName(double degrees) {
    const names = [
      'północny', 'północno-wschodni', 'wschodni', 'południowo-wschodni',
      'południowy', 'południowo-zachodni', 'zachodni', 'północno-zachodni',
    ];
    final idx = (((degrees % 360) + 360) % 360 / 45).round() % 8;
    return names[idx];
  }
}
