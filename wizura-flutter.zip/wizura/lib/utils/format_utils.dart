/// Formatowanie dat i liczb po polsku bez zależności od pakietu `intl`.
class FormatUtils {
  FormatUtils._();

  static const _weekdaysShort = ['pon', 'wt', 'śr', 'czw', 'pt', 'sob', 'niedz'];
  static const _weekdaysLong = [
    'poniedziałek', 'wtorek', 'środa', 'czwartek', 'piątek', 'sobota', 'niedziela',
  ];
  static const _monthsGenitive = [
    'sty', 'lut', 'mar', 'kwi', 'maj', 'cze',
    'lip', 'sie', 'wrz', 'paź', 'lis', 'gru',
  ];

  static String weekdayShort(DateTime d) => _weekdaysShort[d.weekday - 1];
  static String weekdayLong(DateTime d) => _weekdaysLong[d.weekday - 1];

  /// "5 wrz"
  static String dayMonth(DateTime d) => '${d.day} ${_monthsGenitive[d.month - 1]}';

  /// "Dziś", "Jutro" lub "śr 7 wrz"
  static String relativeDay(DateTime d, {DateTime? now}) {
    final n = now ?? DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final day = DateTime(d.year, d.month, d.day);
    final diff = day.difference(today).inDays;
    if (diff == 0) return 'Dziś';
    if (diff == 1) return 'Jutro';
    return '${weekdayShort(d)} ${dayMonth(d)}';
  }

  /// "sob 5 wrz, 14:05"
  static String dateTime(DateTime d) =>
      '${weekdayShort(d)} ${dayMonth(d)}, ${hourMinute(d)}';

  static String hourMinute(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  static String meters(double v, {int decimals = 1}) =>
      '${v.toStringAsFixed(decimals).replaceAll('.', ',')} m';

  static String kmh(double v) => '${v.round()} km/h';

  static String celsius(double v) => '${v.toStringAsFixed(1).replaceAll('.', ',')} °C';

  static String seconds(double v) => '${v.toStringAsFixed(1).replaceAll('.', ',')} s';

  static String percent(int p) => p > 0 ? '+$p%' : '$p%';
}
