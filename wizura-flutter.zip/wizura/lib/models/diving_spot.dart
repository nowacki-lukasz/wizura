/// Sposób wejścia do wody na danym spocie.
enum EntryType {
  shore,
  boat,
  shoreOrBoat;

  String get label => switch (this) {
        EntryType.shore => 'Wejście z brzegu',
        EntryType.boat => 'Konieczna łódź',
        EntryType.shoreOrBoat => 'Brzeg lub łódź',
      };
}

/// Statyczna definicja miejsca nurkowego w Zatoce Gdańskiej.
class DivingSpot {
  const DivingSpot({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.depthLabel,
    required this.minDepth,
    required this.maxDepth,
    required this.shoreFacingAngle,
    required this.entryType,
    required this.description,
    required this.vistulaInfluence,
  });

  final String id;
  final String name;
  final double latitude;
  final double longitude;

  /// Etykieta głębokości, np. "11-21m".
  final String depthLabel;
  final double minDepth;
  final double maxDepth;

  /// Kąt ekspozycji brzegu (kierunek, w który "patrzy" brzeg – w stronę morza).
  /// 0° = N, 90° = E, 180° = S, 270° = W. Wartość -1 oznacza otwarte morze.
  final double shoreFacingAngle;

  final EntryType entryType;
  final String description;

  /// Wrażliwość spotu na smugę zmętnienia z Wisły (0 = brak, 1 = ujście).
  final double vistulaInfluence;

  bool get isOpenWater => shoreFacingAngle < 0;

  /// Głębokie spoty (poniżej termokliny) mają zwykle lepszą wizurę
  /// niż płytkie, wzburzane przez falę przybrzeżną.
  bool get isDeep => maxDepth >= 30;

  bool get isShallow => maxDepth <= 12;
}
