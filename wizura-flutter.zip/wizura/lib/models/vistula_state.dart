/// Aktualny stan Wisły ze stacji IMGW (domyślnie Tczew).
class VistulaState {
  const VistulaState({
    required this.stationName,
    required this.fetchedAt,
    this.waterLevelCm,
    this.flowM3s,
    this.warningLevelCm,
    this.alarmLevelCm,
    this.measuredAt,
  });

  final String stationName;
  final DateTime fetchedAt;

  /// Stan wody [cm].
  final double? waterLevelCm;

  /// Przepływ [m³/s] – nie zawsze dostępny.
  final double? flowM3s;
  final double? warningLevelCm;
  final double? alarmLevelCm;
  final DateTime? measuredAt;

  bool get hasData => waterLevelCm != null || flowM3s != null;

  Map<String, dynamic> toJson() => {
        'station': stationName,
        'fetchedAt': fetchedAt.toIso8601String(),
        'level': waterLevelCm,
        'flow': flowM3s,
        'warn': warningLevelCm,
        'alarm': alarmLevelCm,
        'measuredAt': measuredAt?.toIso8601String(),
      };

  factory VistulaState.fromJson(Map<String, dynamic> json) => VistulaState(
        stationName: json['station'] as String,
        fetchedAt: DateTime.parse(json['fetchedAt'] as String),
        waterLevelCm: _d(json['level']),
        flowM3s: _d(json['flow']),
        warningLevelCm: _d(json['warn']),
        alarmLevelCm: _d(json['alarm']),
        measuredAt: json['measuredAt'] == null
            ? null
            : DateTime.parse(json['measuredAt'] as String),
      );

  static double? _d(dynamic v) => v == null ? null : (v as num).toDouble();
}
