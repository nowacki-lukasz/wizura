/// Jedna godzina scalonych danych z Open-Meteo (Marine + Weather).
/// Wszystkie wartości mogą być `null`, jeśli model nie zwrócił danych.
class HourData {
  const HourData({
    required this.time,
    this.waveHeight,
    this.waveDirection,
    this.wavePeriod,
    this.windWaveHeight,
    this.windWavePeriod,
    this.swellWaveHeight,
    this.seaSurfaceTemperature,
    this.windSpeed,
    this.windDirection,
    this.windGusts,
    this.precipitation,
  });

  final DateTime time;

  /// Wysokość fali znacznej Hs [m].
  final double? waveHeight;

  /// Kierunek, z którego nadchodzi fala [°].
  final double? waveDirection;

  /// Okres fali [s].
  final double? wavePeriod;
  final double? windWaveHeight;
  final double? windWavePeriod;
  final double? swellWaveHeight;

  /// Temperatura powierzchni morza [°C].
  final double? seaSurfaceTemperature;

  /// Prędkość wiatru na 10 m [km/h].
  final double? windSpeed;

  /// Kierunek, z którego wieje wiatr [°].
  final double? windDirection;

  /// Porywy wiatru [km/h].
  final double? windGusts;

  /// Opad w danej godzinie [mm].
  final double? precipitation;

  HourData merge(HourData other) => HourData(
        time: time,
        waveHeight: waveHeight ?? other.waveHeight,
        waveDirection: waveDirection ?? other.waveDirection,
        wavePeriod: wavePeriod ?? other.wavePeriod,
        windWaveHeight: windWaveHeight ?? other.windWaveHeight,
        windWavePeriod: windWavePeriod ?? other.windWavePeriod,
        swellWaveHeight: swellWaveHeight ?? other.swellWaveHeight,
        seaSurfaceTemperature:
            seaSurfaceTemperature ?? other.seaSurfaceTemperature,
        windSpeed: windSpeed ?? other.windSpeed,
        windDirection: windDirection ?? other.windDirection,
        windGusts: windGusts ?? other.windGusts,
        precipitation: precipitation ?? other.precipitation,
      );

  Map<String, dynamic> toJson() => {
        't': time.toIso8601String(),
        'wh': waveHeight,
        'wd': waveDirection,
        'wp': wavePeriod,
        'wwh': windWaveHeight,
        'wwp': windWavePeriod,
        'swh': swellWaveHeight,
        'sst': seaSurfaceTemperature,
        'ws': windSpeed,
        'wdir': windDirection,
        'wg': windGusts,
        'pr': precipitation,
      };

  factory HourData.fromJson(Map<String, dynamic> json) => HourData(
        time: DateTime.parse(json['t'] as String),
        waveHeight: _d(json['wh']),
        waveDirection: _d(json['wd']),
        wavePeriod: _d(json['wp']),
        windWaveHeight: _d(json['wwh']),
        windWavePeriod: _d(json['wwp']),
        swellWaveHeight: _d(json['swh']),
        seaSurfaceTemperature: _d(json['sst']),
        windSpeed: _d(json['ws']),
        windDirection: _d(json['wdir']),
        windGusts: _d(json['wg']),
        precipitation: _d(json['pr']),
      );

  static double? _d(dynamic v) => v == null ? null : (v as num).toDouble();
}
