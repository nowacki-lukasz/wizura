import 'diving_spot.dart';
import 'spot_forecast.dart';
import 'time_block.dart';
import 'visibility_estimate.dart';

/// Podsumowanie jednego dnia (4 bloki po 6 h).
class DayAnalysis {
  const DayAnalysis({required this.date, required this.blocks});

  /// Północ danego dnia (czas lokalny).
  final DateTime date;
  final List<TimeBlock> blocks;

  TimeBlock get bestBlock => blocks.reduce(
      (a, b) => b.estimate.meters > a.estimate.meters ? b : a);

  TimeBlock get worstBlock => blocks.reduce(
      (a, b) => b.estimate.meters < a.estimate.meters ? b : a);

  double get maxVisibility => bestBlock.estimate.meters;

  double get avgVisibility =>
      blocks.fold<double>(0, (s, b) => s + b.estimate.meters) / blocks.length;

  ConditionCategory get category =>
      ConditionCategory.fromVisibility(maxVisibility);
}

/// Ocena wejścia i rekomendacja nurkowa dla danego dnia.
class Recommendation {
  const Recommendation({
    required this.entryAssessment,
    required this.summary,
    required this.warnings,
  });

  /// Np. "Wejście z brzegu – bezpieczne".
  final String entryAssessment;
  final String summary;
  final List<String> warnings;
}

/// Pełna analiza spotu: bloki, dni, "teraz" i rekomendacje.
class SpotAnalysis {
  const SpotAnalysis({
    required this.spot,
    required this.forecast,
    required this.blocks,
    required this.days,
    required this.current,
    required this.recommendations,
  });

  final DivingSpot spot;
  final SpotForecast forecast;

  /// Wszystkie bloki (20 = 5 dni × 4).
  final List<TimeBlock> blocks;
  final List<DayAnalysis> days;

  /// Blok obejmujący "teraz" (lub pierwszy dostępny).
  final TimeBlock current;

  /// Rekomendacja per dzień (indeks = indeks w [days]).
  final List<Recommendation> recommendations;

  DayAnalysis get today => days.first;

  Recommendation get todayRecommendation => recommendations.first;
}
