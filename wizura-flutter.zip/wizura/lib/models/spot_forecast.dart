import 'hour_data.dart';
import 'vistula_state.dart';

/// Surowe dane prognostyczne dla jednego spotu (godzinowe, z historią).
class SpotForecast {
  const SpotForecast({
    required this.spotId,
    required this.fetchedAt,
    required this.hours,
    this.vistula,
  });

  final String spotId;
  final DateTime fetchedAt;

  /// Posortowane rosnąco po czasie; obejmują ok. 3 dni wstecz i 5 dni prognozy.
  final List<HourData> hours;
  final VistulaState? vistula;

  SpotForecast copyWith({VistulaState? vistula}) => SpotForecast(
        spotId: spotId,
        fetchedAt: fetchedAt,
        hours: hours,
        vistula: vistula ?? this.vistula,
      );

  Map<String, dynamic> toJson() => {
        'spotId': spotId,
        'fetchedAt': fetchedAt.toIso8601String(),
        'hours': hours.map((h) => h.toJson()).toList(),
        'vistula': vistula?.toJson(),
      };

  factory SpotForecast.fromJson(Map<String, dynamic> json) => SpotForecast(
        spotId: json['spotId'] as String,
        fetchedAt: DateTime.parse(json['fetchedAt'] as String),
        hours: (json['hours'] as List)
            .map((e) => HourData.fromJson(e as Map<String, dynamic>))
            .toList(),
        vistula: json['vistula'] == null
            ? null
            : VistulaState.fromJson(json['vistula'] as Map<String, dynamic>),
      );
}
