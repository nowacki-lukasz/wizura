import 'package:flutter/material.dart';

/// Kategoria warunków wg szacowanej wizury.
enum ConditionCategory {
  good,
  medium,
  poor;

  static ConditionCategory fromVisibility(double meters) {
    if (meters > 4.0) return ConditionCategory.good;
    if (meters >= 2.0) return ConditionCategory.medium;
    return ConditionCategory.poor;
  }

  String get label => switch (this) {
        ConditionCategory.good => 'Dobre warunki',
        ConditionCategory.medium => 'Średnie warunki',
        ConditionCategory.poor => 'Słaba wizura / mleko',
      };

  String get shortLabel => switch (this) {
        ConditionCategory.good => 'Dobre',
        ConditionCategory.medium => 'Średnie',
        ConditionCategory.poor => 'Słabe',
      };

  Color get color => switch (this) {
        ConditionCategory.good => const Color(0xFF2E9E4F),
        ConditionCategory.medium => const Color(0xFFE0A100),
        ConditionCategory.poor => const Color(0xFFD63B2F),
      };

  Color get onColor => Colors.white;
}

/// Pojedynczy czynnik wpływający na wizurę (do rozbicia wyniku na składowe).
class VisibilityFactor {
  const VisibilityFactor({
    required this.key,
    required this.label,
    required this.multiplier,
    required this.note,
  });

  final String key;
  final String label;

  /// Mnożnik zastosowany do wizury (1.0 = brak wpływu).
  final double multiplier;
  final String note;

  /// Zmiana procentowa, np. -55 lub +10.
  int get percent => ((multiplier - 1.0) * 100).round();

  bool get isNeutral => percent == 0;
  bool get isPositive => percent > 0;
}

/// Wynik algorytmu estymacji wizury dla jednego bloku czasowego.
class VisibilityEstimate {
  const VisibilityEstimate({
    required this.meters,
    required this.rawMeters,
    required this.factors,
    required this.notes,
  });

  /// Wizura po obcięciu do 0.5–8.0 m i zaokrągleniu do 0.1 m.
  final double meters;

  /// Wizura przed obcięciem (do celów diagnostycznych).
  final double rawMeters;
  final List<VisibilityFactor> factors;

  /// Dodatkowe uwagi (np. brak danych o fali – użyto estymacji z wiatru).
  final List<String> notes;

  ConditionCategory get category => ConditionCategory.fromVisibility(meters);
}
