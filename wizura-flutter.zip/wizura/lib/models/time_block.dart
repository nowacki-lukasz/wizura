import 'visibility_estimate.dart';

/// Uśrednione warunki w bloku 6-godzinnym – wejście do [VisibilityCalculator].
class BlockConditions {
  const BlockConditions({
    this.windSpeed,
    this.windGusts,
    this.windDirection,
    this.waveHeight,
    this.wavePeriod,
    this.waveDirection,
    this.windWaveHeight,
    this.swellWaveHeight,
    this.seaSurfaceTemperature,
    this.seaSurfaceTemperature48hAgo,
    this.precipitation72h,
    this.maxWaveHeight24h,
    this.vistulaLevelCm,
    this.vistulaFlowM3s,
    this.vistulaWarningLevelCm,
  });

  /// [km/h]
  final double? windSpeed;
  final double? windGusts;

  /// Kierunek, z którego wieje wiatr [°].
  final double? windDirection;

  /// [m]
  final double? waveHeight;
  final double? wavePeriod;
  final double? waveDirection;
  final double? windWaveHeight;
  final double? swellWaveHeight;

  /// [°C]
  final double? seaSurfaceTemperature;
  final double? seaSurfaceTemperature48hAgo;

  /// Suma opadu w 72 h poprzedzających blok [mm].
  final double? precipitation72h;

  /// Maksymalna fala w 24 h poprzedzających blok [m].
  final double? maxWaveHeight24h;

  final double? vistulaLevelCm;
  final double? vistulaFlowM3s;
  final double? vistulaWarningLevelCm;

  /// Efektywna prędkość wiatru z uwzględnieniem porywów.
  double? get effectiveWindSpeed {
    if (windSpeed == null) return null;
    if (windGusts == null) return windSpeed;
    return 0.7 * windSpeed! + 0.3 * windGusts!;
  }

  bool get hasWaveData => waveHeight != null;
}

/// Blok 6-godzinny z policzoną wizurą.
class TimeBlock {
  const TimeBlock({
    required this.start,
    required this.end,
    required this.conditions,
    required this.estimate,
  });

  final DateTime start;

  /// Koniec bloku (wyłącznie).
  final DateTime end;
  final BlockConditions conditions;
  final VisibilityEstimate estimate;

  String get hourLabel =>
      '${start.hour.toString().padLeft(2, '0')}–${end.hour == 0 ? '24' : end.hour.toString().padLeft(2, '0')}';

  bool contains(DateTime t) => !t.isBefore(start) && t.isBefore(end);

  int get indexInDay => start.hour ~/ 6;
}
