import 'package:flutter/material.dart';

import 'views/home_view.dart';

class WizuraApp extends StatelessWidget {
  const WizuraApp({super.key});

  static const Color _seed = Color(0xFF0B5FA5);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wizura – Zatoka Gdańska',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: _seed),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: _seed,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      themeMode: ThemeMode.system,
      home: const HomeView(),
    );
  }
}
