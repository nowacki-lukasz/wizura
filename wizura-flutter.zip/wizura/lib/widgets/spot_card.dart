import 'package:flutter/material.dart';

import '../models/diving_spot.dart';
import '../models/spot_analysis.dart';
import '../utils/format_utils.dart';
import 'metric_chip.dart';
import 'visibility_badge.dart';
import 'wind_arrow.dart';

/// Karta spotu na liście głównej.
class SpotCard extends StatelessWidget {
  const SpotCard({
    super.key,
    required this.analysis,
    required this.onTap,
  });

  final SpotAnalysis analysis;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final spot = analysis.spot;
    final current = analysis.current;
    final c = current.conditions;
    final theme = Theme.of(context);
    final today = analysis.today;

    return Card(
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      spot.name,
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Icon(
                          spot.entryType == EntryType.boat
                              ? Icons.directions_boat
                              : Icons.beach_access,
                          size: 14,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${spot.entryType.label} · teraz ${current.hourLabel}',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 16,
                      runSpacing: 6,
                      children: [
                        MetricChip(
                          icon: Icons.waves,
                          value: c.waveHeight == null
                              ? '—'
                              : FormatUtils.meters(c.waveHeight!),
                          label: 'fala',
                        ),
                        MetricChip(
                          icon: Icons.air,
                          value: '',
                          label: 'wiatr',
                          child: WindArrow(
                            directionFrom: c.windDirection,
                            speedKmh: c.effectiveWindSpeed,
                            gustsKmh: c.windGusts,
                            size: 16,
                          ),
                        ),
                        MetricChip(
                          icon: Icons.straighten,
                          value: spot.depthLabel,
                          label: 'głębokość',
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Text(
                          'Dziś: ',
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        for (final b in today.blocks) ...[
                          Tooltip(
                            message:
                                '${b.hourLabel}: ${FormatUtils.meters(b.estimate.meters)}',
                            child: ConditionDot(meters: b.estimate.meters, size: 12),
                          ),
                          const SizedBox(width: 4),
                        ],
                        const SizedBox(width: 6),
                        Text(
                          'max ${FormatUtils.meters(today.maxVisibility)} (${today.bestBlock.hourLabel})',
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              VisibilityBadge(meters: current.estimate.meters),
            ],
          ),
        ),
      ),
    );
  }
}
