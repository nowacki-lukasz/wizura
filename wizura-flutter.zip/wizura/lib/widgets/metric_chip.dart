import 'package:flutter/material.dart';

/// Mały wskaźnik "ikona + wartość" z opcjonalnym podpisem.
class MetricChip extends StatelessWidget {
  const MetricChip({
    super.key,
    required this.icon,
    required this.value,
    this.label,
    this.child,
    this.color,
  });

  final IconData icon;
  final String value;
  final String? label;

  /// Alternatywnie zamiast tekstu można podać własny widget (np. strzałkę).
  final Widget? child;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 18, color: color ?? scheme.primary),
            const SizedBox(width: 4),
            child ?? Text(value, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
        if (label != null)
          Padding(
            padding: const EdgeInsets.only(left: 22),
            child: Text(
              label!,
              style: Theme.of(context)
                  .textTheme
                  .labelSmall
                  ?.copyWith(color: scheme.onSurfaceVariant),
            ),
          ),
      ],
    );
  }
}
