import 'package:flutter/material.dart';

import '../models/time_block.dart';
import '../models/visibility_estimate.dart';
import '../utils/format_utils.dart';

/// Wykres słupkowy wizury dla 20 bloków 6-godzinnych (5 dni).
/// Dotknięcie słupka wywołuje [onSelect].
class VisibilityChart extends StatelessWidget {
  const VisibilityChart({
    super.key,
    required this.blocks,
    required this.selectedIndex,
    required this.onSelect,
    this.height = 190,
    this.now,
  });

  final List<TimeBlock> blocks;
  final int selectedIndex;
  final ValueChanged<int> onSelect;
  final double height;
  final DateTime? now;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        return GestureDetector(
          onTapDown: (d) => _handleTap(d.localPosition.dx, width),
          onHorizontalDragUpdate: (d) => _handleTap(d.localPosition.dx, width),
          child: CustomPaint(
            size: Size(width, height),
            painter: _ChartPainter(
              blocks: blocks,
              selectedIndex: selectedIndex,
              now: now ?? DateTime.now(),
              textColor: theme.colorScheme.onSurface,
              mutedColor: theme.colorScheme.onSurfaceVariant,
              gridColor: theme.colorScheme.outlineVariant,
              selectionColor: theme.colorScheme.primary,
              dayLabelStyle: theme.textTheme.labelSmall!,
            ),
          ),
        );
      },
    );
  }

  void _handleTap(double dx, double width) {
    final plotLeft = _ChartPainter.leftPad;
    final plotWidth = width - plotLeft - _ChartPainter.rightPad;
    if (plotWidth <= 0) return;
    final slot = plotWidth / blocks.length;
    final idx = ((dx - plotLeft) / slot).floor().clamp(0, blocks.length - 1);
    onSelect(idx);
  }
}

class _ChartPainter extends CustomPainter {
  _ChartPainter({
    required this.blocks,
    required this.selectedIndex,
    required this.now,
    required this.textColor,
    required this.mutedColor,
    required this.gridColor,
    required this.selectionColor,
    required this.dayLabelStyle,
  });

  final List<TimeBlock> blocks;
  final int selectedIndex;
  final DateTime now;
  final Color textColor;
  final Color mutedColor;
  final Color gridColor;
  final Color selectionColor;
  final TextStyle dayLabelStyle;

  static const double leftPad = 28;
  static const double rightPad = 8;
  static const double topPad = 18;
  static const double bottomPad = 34;
  static const double maxValue = 8.0;

  @override
  void paint(Canvas canvas, Size size) {
    final plotLeft = leftPad;
    final plotTop = topPad;
    final plotWidth = size.width - leftPad - rightPad;
    final plotHeight = size.height - topPad - bottomPad;
    final plotBottom = plotTop + plotHeight;
    if (plotWidth <= 0 || plotHeight <= 0 || blocks.isEmpty) return;

    final slot = plotWidth / blocks.length;
    final barWidth = slot * 0.7;

    // Siatka pozioma i etykiety osi Y (0, 2, 4, 6, 8 m).
    final gridPaint = Paint()
      ..color = gridColor
      ..strokeWidth = 1;
    for (var v = 0; v <= maxValue; v += 2) {
      final y = plotBottom - (v / maxValue) * plotHeight;
      canvas.drawLine(Offset(plotLeft, y), Offset(plotLeft + plotWidth, y), gridPaint);
      _drawText(canvas, '$v m', Offset(0, y - 6),
          TextStyle(color: mutedColor, fontSize: 10), maxWidth: leftPad - 4);
    }

    // Linie progów 2 m i 4 m (granice kategorii).
    final thresholdPaint = Paint()
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    for (final t in [2.0, 4.0]) {
      final y = plotBottom - (t / maxValue) * plotHeight;
      thresholdPaint.color = (t == 4.0
              ? ConditionCategory.good.color
              : ConditionCategory.medium.color)
          .withValues(alpha: 0.5);
      _drawDashed(canvas, Offset(plotLeft, y), Offset(plotLeft + plotWidth, y), thresholdPaint);
    }

    // Słupki.
    for (var i = 0; i < blocks.length; i++) {
      final b = blocks[i];
      final v = b.estimate.meters.clamp(0.0, maxValue);
      final x = plotLeft + i * slot + (slot - barWidth) / 2;
      final h = (v / maxValue) * plotHeight;
      final rect = RRect.fromRectAndCorners(
        Rect.fromLTWH(x, plotBottom - h, barWidth, h),
        topLeft: const Radius.circular(3),
        topRight: const Radius.circular(3),
      );
      final isPast = b.end.isBefore(now);
      final paint = Paint()
        ..color = b.estimate.category.color.withValues(alpha: isPast ? 0.45 : 1.0);
      canvas.drawRRect(rect, paint);

      if (i == selectedIndex) {
        final outline = Paint()
          ..color = selectionColor
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2;
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromLTWH(x - 2, plotBottom - h - 2, barWidth + 4, h + 2),
            const Radius.circular(4),
          ),
          outline,
        );
        _drawText(
          canvas,
          FormatUtils.meters(b.estimate.meters),
          Offset(x + barWidth / 2 - 18, plotBottom - h - 16),
          TextStyle(color: textColor, fontSize: 11, fontWeight: FontWeight.w600),
          maxWidth: 40,
          align: TextAlign.center,
        );
      }
    }

    // Separator dni + etykiety.
    final sepPaint = Paint()
      ..color = mutedColor.withValues(alpha: 0.5)
      ..strokeWidth = 1;
    for (var i = 0; i < blocks.length; i++) {
      if (blocks[i].start.hour != 0) continue;
      final x = plotLeft + i * slot;
      if (i > 0) {
        canvas.drawLine(Offset(x, plotTop), Offset(x, plotBottom + 4), sepPaint);
      }
      final dayBlocks = blocks.skip(i).take(4).length;
      final label = FormatUtils.relativeDay(blocks[i].start, now: now);
      _drawText(
        canvas,
        label,
        Offset(x, plotBottom + 6),
        dayLabelStyle.copyWith(color: textColor, fontWeight: FontWeight.w600),
        maxWidth: slot * dayBlocks,
        align: TextAlign.center,
      );
    }

    // Etykiety godzin (tylko 00 / 12 dla czytelności).
    for (var i = 0; i < blocks.length; i++) {
      final hour = blocks[i].start.hour;
      if (hour != 0 && hour != 12) continue;
      final x = plotLeft + i * slot;
      _drawText(
        canvas,
        hour.toString().padLeft(2, '0'),
        Offset(x, plotBottom + 20),
        TextStyle(color: mutedColor, fontSize: 9),
        maxWidth: slot,
        align: TextAlign.center,
      );
    }

    // Znacznik "teraz".
    final idxNow = blocks.indexWhere((b) => b.contains(now));
    if (idxNow >= 0) {
      final b = blocks[idxNow];
      final frac = now.difference(b.start).inMinutes / b.end.difference(b.start).inMinutes;
      final x = plotLeft + (idxNow + frac) * slot;
      final nowPaint = Paint()
        ..color = selectionColor
        ..strokeWidth = 1.5;
      canvas.drawLine(Offset(x, plotTop - 4), Offset(x, plotBottom), nowPaint);
      final tri = Path()
        ..moveTo(x - 4, plotTop - 8)
        ..lineTo(x + 4, plotTop - 8)
        ..lineTo(x, plotTop - 2)
        ..close();
      canvas.drawPath(tri, Paint()..color = selectionColor);
    }
  }

  void _drawText(
    Canvas canvas,
    String text,
    Offset offset,
    TextStyle style, {
    required double maxWidth,
    TextAlign align = TextAlign.left,
  }) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
      textAlign: align,
      maxLines: 1,
      ellipsis: '…',
    )..layout(minWidth: maxWidth, maxWidth: maxWidth);
    tp.paint(canvas, offset);
  }

  void _drawDashed(Canvas canvas, Offset a, Offset b, Paint paint) {
    const dash = 4.0;
    const gap = 4.0;
    var x = a.dx;
    while (x < b.dx) {
      final x2 = (x + dash).clamp(a.dx, b.dx);
      canvas.drawLine(Offset(x, a.dy), Offset(x2, a.dy), paint);
      x += dash + gap;
    }
  }

  @override
  bool shouldRepaint(covariant _ChartPainter old) =>
      old.blocks != blocks ||
      old.selectedIndex != selectedIndex ||
      old.now != now ||
      old.textColor != textColor;
}
