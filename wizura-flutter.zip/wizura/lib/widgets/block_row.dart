import 'package:flutter/material.dart';

import '../models/time_block.dart';
import '../utils/format_utils.dart';
import 'visibility_badge.dart';
import 'wind_arrow.dart';

/// Wiersz jednego bloku 6-godzinnego: godziny, badge, wiatr, fala, SST.
class BlockRow extends StatelessWidget {
  const BlockRow({
    super.key,
    required this.block,
    required this.selected,
    required this.onTap,
    this.isNow = false,
  });

  final TimeBlock block;
  final bool selected;
  final bool isNow;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final c = block.conditions;
    final wave = c.waveHeight;
    return Material(
      color: selected
          ? theme.colorScheme.primaryContainer.withValues(alpha: 0.5)
          : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            children: [
              SizedBox(
                width: 58,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      block.hourLabel,
                      style: theme.textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                    if (isNow)
                      Text(
                        'teraz',
                        style: theme.textTheme.labelSmall
                            ?.copyWith(color: theme.colorScheme.primary),
                      ),
                  ],
                ),
              ),
              VisibilityBadge(meters: block.estimate.meters, showLabel: false),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    WindArrow(
                      directionFrom: c.windDirection,
                      speedKmh: c.effectiveWindSpeed,
                      gustsKmh: c.windGusts,
                      size: 16,
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Icon(Icons.waves,
                            size: 16, color: theme.colorScheme.onSurfaceVariant),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            wave == null
                                ? 'fala —'
                                : '${FormatUtils.meters(wave)}${c.wavePeriod == null ? '' : ' / ${FormatUtils.seconds(c.wavePeriod!)}'}',
                            style: theme.textTheme.bodyMedium,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (c.seaSurfaceTemperature != null) ...[
                          const SizedBox(width: 10),
                          Icon(Icons.thermostat,
                              size: 16, color: theme.colorScheme.onSurfaceVariant),
                          Text(
                            FormatUtils.celsius(c.seaSurfaceTemperature!),
                            style: theme.textTheme.bodyMedium,
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: theme.colorScheme.outline),
            ],
          ),
        ),
      ),
    );
  }
}
