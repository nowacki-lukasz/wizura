import 'package:flutter/material.dart';

import '../utils/format_utils.dart';

/// Pasek informujący o pracy na danych z pamięci podręcznej.
class OfflineBanner extends StatelessWidget {
  const OfflineBanner({
    super.key,
    required this.updatedAt,
    this.reason,
    this.partialErrorCount = 0,
    this.onRetry,
  });

  final DateTime updatedAt;
  final String? reason;
  final int partialErrorCount;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isOffline = reason != null;
    final text = isOffline
        ? 'Tryb offline – dane z ${FormatUtils.dateTime(updatedAt)}. ${reason!}'
        : partialErrorCount > 0
            ? 'Nie udało się odświeżyć $partialErrorCount ${partialErrorCount == 1 ? 'spotu' : 'spotów'} – pokazuję ostatnie dane.'
            : 'Dane z pamięci podręcznej (${FormatUtils.dateTime(updatedAt)}).';
    return Material(
      color: isOffline ? scheme.errorContainer : scheme.tertiaryContainer,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            Icon(
              isOffline ? Icons.cloud_off : Icons.history,
              size: 18,
              color: isOffline ? scheme.onErrorContainer : scheme.onTertiaryContainer,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                text,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: isOffline
                          ? scheme.onErrorContainer
                          : scheme.onTertiaryContainer,
                    ),
              ),
            ),
            if (onRetry != null)
              TextButton(onPressed: onRetry, child: const Text('Odśwież')),
          ],
        ),
      ),
    );
  }
}
