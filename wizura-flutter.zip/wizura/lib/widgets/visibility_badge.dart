import 'package:flutter/material.dart';

import '../models/visibility_estimate.dart';
import '../utils/format_utils.dart';

/// Kolorowy badge z szacowaną wizurą i opisem warunków.
class VisibilityBadge extends StatelessWidget {
  const VisibilityBadge({
    super.key,
    required this.meters,
    this.large = false,
    this.showLabel = true,
  });

  final double meters;
  final bool large;
  final bool showLabel;

  @override
  Widget build(BuildContext context) {
    final category = ConditionCategory.fromVisibility(meters);
    final valueStyle = large
        ? Theme.of(context).textTheme.headlineMedium
        : Theme.of(context).textTheme.titleMedium;
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: large ? 16 : 10,
        vertical: large ? 10 : 6,
      ),
      decoration: BoxDecoration(
        color: category.color,
        borderRadius: BorderRadius.circular(large ? 16 : 12),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            FormatUtils.meters(meters),
            style: valueStyle?.copyWith(
              color: category.onColor,
              fontWeight: FontWeight.w700,
            ),
          ),
          if (showLabel)
            Text(
              large ? category.label : category.shortLabel,
              style: TextStyle(
                color: category.onColor,
                fontSize: large ? 13 : 11,
                fontWeight: FontWeight.w500,
              ),
            ),
        ],
      ),
    );
  }
}

/// Mały kwadracik koloru warunków (np. 4 bloki dnia w karcie).
class ConditionDot extends StatelessWidget {
  const ConditionDot({super.key, required this.meters, this.size = 10});

  final double meters;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: ConditionCategory.fromVisibility(meters).color,
        borderRadius: BorderRadius.circular(size / 4),
      ),
    );
  }
}
