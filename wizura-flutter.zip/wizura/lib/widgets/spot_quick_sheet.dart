import 'package:flutter/material.dart';

import '../models/spot_analysis.dart';
import '../utils/format_utils.dart';
import 'metric_chip.dart';
import 'visibility_badge.dart';
import 'wind_arrow.dart';

/// Zawartość dolnego arkusza po kliknięciu markera na mapie.
class SpotQuickSheet extends StatelessWidget {
  const SpotQuickSheet({
    super.key,
    required this.analysis,
    required this.onOpenDetails,
  });

  final SpotAnalysis analysis;
  final VoidCallback onOpenDetails;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final spot = analysis.spot;
    final current = analysis.current;
    final c = current.conditions;
    final rec = analysis.todayRecommendation;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: theme.colorScheme.outlineVariant,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(spot.name,
                          style: theme.textTheme.titleLarge
                              ?.copyWith(fontWeight: FontWeight.w600)),
                      Text(
                        '${spot.depthLabel} · ${spot.entryType.label}',
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                      ),
                    ],
                  ),
                ),
                VisibilityBadge(meters: current.estimate.meters, large: true),
              ],
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 18,
              runSpacing: 8,
              children: [
                MetricChip(
                  icon: Icons.waves,
                  value: c.waveHeight == null ? '—' : FormatUtils.meters(c.waveHeight!),
                  label: 'fala',
                ),
                MetricChip(
                  icon: Icons.air,
                  value: '',
                  label: 'wiatr',
                  child: WindArrow(
                    directionFrom: c.windDirection,
                    speedKmh: c.effectiveWindSpeed,
                    gustsKmh: c.windGusts,
                    size: 16,
                  ),
                ),
                if (c.seaSurfaceTemperature != null)
                  MetricChip(
                    icon: Icons.thermostat,
                    value: FormatUtils.celsius(c.seaSurfaceTemperature!),
                    label: 'woda',
                  ),
              ],
            ),
            const SizedBox(height: 14),
            Text('Dziś:', style: theme.textTheme.labelLarge),
            const SizedBox(height: 4),
            Row(
              children: [
                for (final b in analysis.today.blocks)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: Column(
                        children: [
                          Container(
                            height: 6,
                            decoration: BoxDecoration(
                              color: b.estimate.category.color,
                              borderRadius: BorderRadius.circular(3),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${b.hourLabel}\n${FormatUtils.meters(b.estimate.meters)}',
                            textAlign: TextAlign.center,
                            style: theme.textTheme.labelSmall,
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(rec.entryAssessment,
                style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(rec.summary, style: theme.textTheme.bodySmall),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: onOpenDetails,
                icon: const Icon(Icons.timeline),
                label: const Text('Prognoza 5 dni i szczegóły'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
