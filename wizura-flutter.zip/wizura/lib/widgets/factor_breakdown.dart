import 'package:flutter/material.dart';

import '../models/visibility_estimate.dart';
import '../services/visibility_calculator.dart';
import '../utils/format_utils.dart';

/// Rozbicie wyniku algorytmu na czynniki: baza → mnożniki → wynik.
class FactorBreakdown extends StatelessWidget {
  const FactorBreakdown({super.key, required this.estimate});

  final VisibilityEstimate estimate;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.colorScheme.onSurfaceVariant;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _line(
          context,
          icon: Icons.water,
          label: 'Baza (czysta woda Zatoki)',
          value: FormatUtils.meters(VisibilityCalculator.baseVisibility),
          valueColor: theme.colorScheme.onSurface,
        ),
        const Divider(height: 12),
        for (final f in estimate.factors) _factorTile(context, f),
        const Divider(height: 12),
        _line(
          context,
          icon: Icons.visibility,
          label: 'Szacowana wizura',
          value: FormatUtils.meters(estimate.meters),
          valueColor: estimate.category.color,
          bold: true,
        ),
        if (estimate.rawMeters > VisibilityCalculator.maxVisibility ||
            estimate.rawMeters < VisibilityCalculator.minVisibility)
          Padding(
            padding: const EdgeInsets.only(top: 4, left: 26),
            child: Text(
              'Wynik obcięty do zakresu 0,5–8,0 m (surowo: ${estimate.rawMeters.toStringAsFixed(1).replaceAll('.', ',')} m).',
              style: theme.textTheme.labelSmall?.copyWith(color: muted),
            ),
          ),
        for (final n in estimate.notes)
          Padding(
            padding: const EdgeInsets.only(top: 4, left: 26),
            child: Text(n, style: theme.textTheme.labelSmall?.copyWith(color: muted)),
          ),
      ],
    );
  }

  Widget _factorTile(BuildContext context, VisibilityFactor f) {
    final theme = Theme.of(context);
    final Color color;
    final IconData icon;
    if (f.isNeutral) {
      color = theme.colorScheme.onSurfaceVariant;
      icon = Icons.remove;
    } else if (f.isPositive) {
      color = ConditionCategory.good.color;
      icon = Icons.arrow_upward;
    } else if (f.percent <= -40) {
      color = ConditionCategory.poor.color;
      icon = Icons.arrow_downward;
    } else {
      color = ConditionCategory.medium.color;
      icon = Icons.arrow_downward;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(f.label, style: theme.textTheme.bodyMedium),
                Text(
                  f.note,
                  style: theme.textTheme.labelSmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            f.isNeutral ? '0%' : FormatUtils.percent(f.percent),
            style: theme.textTheme.bodyMedium
                ?.copyWith(color: color, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Widget _line(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
    required Color valueColor,
    bool bold = false,
  }) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Icon(icon, size: 18, color: theme.colorScheme.primary),
        const SizedBox(width: 8),
        Expanded(child: Text(label, style: theme.textTheme.bodyMedium)),
        Text(
          value,
          style: (bold ? theme.textTheme.titleMedium : theme.textTheme.bodyMedium)
              ?.copyWith(color: valueColor, fontWeight: FontWeight.w700),
        ),
      ],
    );
  }
}
