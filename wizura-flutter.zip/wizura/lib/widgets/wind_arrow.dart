import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../utils/angle_utils.dart';

/// Strzałka pokazująca, DOKĄD wieje wiatr (Open-Meteo podaje kierunek,
/// SKĄD wieje – stąd obrót o 180°), plus prędkość i nazwa kierunku.
class WindArrow extends StatelessWidget {
  const WindArrow({
    super.key,
    required this.directionFrom,
    required this.speedKmh,
    this.gustsKmh,
    this.size = 20,
    this.compact = false,
  });

  /// Kierunek, z którego wieje wiatr [°].
  final double? directionFrom;
  final double? speedKmh;
  final double? gustsKmh;
  final double size;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.onSurfaceVariant;
    final textStyle = Theme.of(context).textTheme.bodyMedium;
    if (speedKmh == null) {
      return Text('— km/h', style: textStyle);
    }
    final dir = directionFrom;
    final label = compact
        ? '${speedKmh!.round()}'
        : '${speedKmh!.round()} km/h${dir == null ? '' : ' ${AngleUtils.compassName(dir)}'}';
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (dir != null)
          Transform.rotate(
            angle: (dir + 180) * math.pi / 180,
            child: Icon(Icons.navigation, size: size, color: _speedColor(speedKmh!, color)),
          )
        else
          Icon(Icons.air, size: size, color: color),
        const SizedBox(width: 4),
        Text(label, style: textStyle),
        if (!compact && gustsKmh != null && gustsKmh! > speedKmh! + 10)
          Text(
            ' (${gustsKmh!.round()})',
            style: textStyle?.copyWith(color: color, fontSize: 12),
          ),
      ],
    );
  }

  Color _speedColor(double speed, Color fallback) {
    if (speed >= 40) return const Color(0xFFD63B2F);
    if (speed >= 25) return const Color(0xFFE0A100);
    return fallback;
  }
}
