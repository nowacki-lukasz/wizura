# Wizura – prognoza widoczności podwodnej w Zatoce Gdańskiej

Aplikacja mobilna (Flutter / Android) szacująca wizurę w metrach dla 10 spotów nurkowych
Zatoki Gdańskiej na dziś i 4 kolejne dni, w blokach 6-godzinnych. Architektura
**client-only** – brak własnego backendu, wszystkie zapytania API i obliczenia
wykonują się na telefonie. Po pierwszym pobraniu prognozy aplikacja działa offline
(cache w `shared_preferences`).

## Jak zbudować APK

### Wariant A – GitHub Actions (bez instalowania czegokolwiek)

1. Utwórz nowe repozytorium na GitHub i wgraj zawartość tego folderu (`git init`, `git add .`, `git commit`, `git push`).
2. Wejdź w zakładkę **Actions** → workflow **Build Android APK** uruchomi się automatycznie
   (lub kliknij **Run workflow**).
3. Po ok. 5–8 minutach pobierz artefakt **wizura-debug-apk** (i opcjonalnie **wizura-release-apk**).
4. Rozpakuj ZIP, przerzuć `app-debug.apk` na telefon i zainstaluj (zezwól na instalację z nieznanych źródeł).

Workflow: `.github/workflows/build-apk.yml` (Flutter 3.35.x, Java 17, `flutter analyze`, `flutter test`, `flutter build apk`).

### Wariant B – lokalnie

Wymagania: Flutter SDK ≥ 3.27 (stable), Android SDK (Android Studio), Java 17.

```bash
flutter pub get
flutter test               # testy algorytmu, analizy i parsowania API
flutter run                # uruchomienie na podłączonym telefonie / emulatorze
flutter build apk --debug  # build/app/outputs/flutter-apk/app-debug.apk
```

> Jeśli używasz nowszej wersji Fluttera, która wymaga nowszego Android Gradle Plugin,
> podnieś wersje w `android/settings.gradle.kts` (`com.android.application`,
> `org.jetbrains.kotlin.android`) i `android/gradle/wrapper/gradle-wrapper.properties`.
> Alternatywnie: usuń folder `android/` i uruchom `flutter create --platforms=android --org eu.neoteric .`,
> a następnie dodaj uprawnienie `INTERNET` do `AndroidManifest.xml`.

## Struktura projektu

```
lib/
  main.dart / app.dart          – wejście, motyw (Material 3, tryb ciemny)
  data/diving_spots.dart        – 10 spotów zapisanych na sztywno
  models/                       – DivingSpot, HourData, SpotForecast, VistulaState,
                                  TimeBlock/BlockConditions, VisibilityEstimate, SpotAnalysis
  services/
    open_meteo_service.dart     – Marine + Weather API (parsowanie, scalanie po czasie)
    imgw_service.dart           – stan/przepływ Wisły w Tczewie (IMGW-PIB)
    visibility_calculator.dart  – algorytm wizury (czysta funkcja, testowalna)
    forecast_analyzer.dart      – bloki 6 h, dni, rekomendacje, ocena wejścia
    forecast_repository.dart    – orkiestracja pobierania + cache
    forecast_cache_service.dart – shared_preferences
  providers/forecast_providers.dart – Riverpod (AsyncNotifier, family providers)
  views/                        – HomeView (Lista/Mapa), SpotListView, SpotMapView, SpotDetailView
  widgets/                      – karty, badge, strzałka wiatru, wykres (CustomPaint), rozbicie czynników
test/                           – 50+ testów jednostkowych
```

## Źródła danych (bez kluczy API)

| Dane | Źródło | Parametry |
|---|---|---|
| Fala: wysokość, kierunek, okres, fala wiatrowa, martwa fala, temperatura wody | Open-Meteo Marine API | `wave_height, wave_direction, wave_period, wind_wave_height, wind_wave_period, swell_wave_height, sea_surface_temperature`, `past_days=3`, `forecast_days=6` |
| Wiatr 10 m, porywy, opady | Open-Meteo Weather API | `wind_speed_10m, wind_direction_10m, wind_gusts_10m, precipitation`, `past_days=3` |
| Stan i przepływ Wisły (Tczew, id 154180150) | IMGW-PIB `danepubliczne.imgw.pl/api/data/hydro` | `stan_wody`, `przeplyw`, `stan_ostrzegawczy` |
| Mapa | OpenStreetMap (flutter_map) | kafelki `tile.openstreetmap.org` |

## Algorytm wizury (`VisibilityCalculator`)

Wynik = **5,5 m × iloczyn mnożników**, obcięty do 0,5–8,0 m, zaokrąglony do 0,1 m.

| # | Czynnik | Reguła |
|---|---|---|
| 1 | Wiatr vs brzeg | onshore (Δ < 45°): −25 % (≤ 10 km/h) … −60 % (≥ 40 km/h), liniowo; offshore (Δ > 135°): +10 %; wzdłuż brzegu: 0 … −15 % rosnąco od 15 km/h. Prędkość efektywna = 0,7·wiatr + 0,3·porywy. Otwarte morze: −10 % tylko przy > 35 km/h. |
| 2 | Wysokość fali Hs | < 0,3 m ×1,0; 0,3–0,8 ×0,75; 0,8–1,5 ×0,45; > 1,5 ×0,2. Brak danych z modelu → Hs ≈ 0,0075·U² z wiatru. |
| 3 | Historia falowania | max Hs w poprzednich 24 h > 1,0 m → ×0,65 |
| 4 | Charakter fali *(dodatek)* | okres < 4 s na płytkim spocie (≤ 12 m) → ×0,85; martwa fala > 7 s → ×1,05; fala ≥ 0,5 m prosto w brzeg → ×0,85 |
| 5a | Opady 72 h *(dodatek)* | > 5 mm ×0,95; > 15 mm ×0,85; > 30 mm ×0,7 |
| 5b | Smuga Wisły *(dodatek)* | przepływ > 1000 m³/s (lub stan > 50 % ostrzegawczego) → kara 0,75; > 1600 m³/s (> 75 %) → 0,5; skalowana wagą spotu (Górki 1,0; Sopot/Orłowo/Formoza/Babie Doły 0,3; Hel/Rewa/Mechelinki 0,15; Franken 0,1) |
| 6 | Temperatura wody *(dodatek)* | VI–IX: ≥ 16 °C ×0,9; ≥ 18 °C ×0,8; ≥ 20 °C ×0,7 (zakwit). Upwelling: spadek SST ≥ 3 °C vs 48 h wcześniej przy wietrze od lądu → ×1,15 |
| 7 | Głębokość *(dodatek)* | spot ≥ 30 m (Franken) → ×1,3 (pod termokliną) |

Każdy blok 6 h pokazuje na ekranie szczegółów pełne rozbicie: baza → czynniki (%) → wynik.

## Kolory

- zielony – wizura > 4,0 m („Dobre warunki”)
- żółty – 2,0–4,0 m („Średnie warunki”)
- czerwony – < 2,0 m („Słaba wizura / mleko”)

## Uwagi

- Estymacja jest statystyczna. Model fal Open-Meteo ma rozdzielczość ~5 km, więc przy samym brzegu
  (Sopot, Orłowo) fala bywa niedoszacowana lub w ogóle nie zwrócona – wtedy używana jest estymacja z wiatru.
- Mapa wymaga internetu (kafelki OSM); lista i szczegóły działają offline z cache.
- Cache uznawany jest za świeży przez 3 h; „pociągnij, aby odświeżyć” wymusza pobranie.
